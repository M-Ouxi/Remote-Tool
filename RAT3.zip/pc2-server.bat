@echo off
setlocal
title PC-2 instellen
REM ============================================================
REM  pc2-server.bat  -  draai dit op PC-2 (de pc die bestuurd wordt)
REM  Dubbelklik en kies Ja bij de Windows-vraag (administrator).
REM  Je ziet de voortgang in een venster (1 tot 3 minuten). Aan het
REM  eind krijg je een melding met het resultaat en de gegevens voor
REM  PC-1. Het venster sluit daarna vanzelf. Veilig om opnieuw te draaien.
REM ============================================================

set "SELF=%~f0"
set "PS1=%TEMP%\remote-pc2-server.ps1"

if /i "%~1"=="elevated" goto run

REM Niet als administrator gestart: opnieuw starten als administrator
powershell -NoProfile -Command "Start-Process -FilePath $env:SELF -ArgumentList 'elevated' -Verb RunAs"
if errorlevel 1 goto noadmin
exit /b

:noadmin
echo.
echo Starten als administrator is niet gelukt, of je hebt op Nee geklikt.
echo Dubbelklik het bestand opnieuw en kies Ja bij de Windows-vraag.
echo.
pause
exit /b 1

:run
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:SELF); $i=$s.LastIndexOf('#PS-START',[StringComparison]::Ordinal); [IO.File]::WriteAllText($env:PS1,$s.Substring($i))"
if not exist "%PS1%" goto noextract
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%errorlevel%"
del "%PS1%" >nul 2>&1
if not "%RC%"=="0" pause
exit /b %RC%

:noextract
echo.
echo Kon het script niet uitpakken in de map %TEMP%.
echo.
pause
exit /b 1

#PS-START
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'PC-2 instellen'

$base = Join-Path $env:ProgramData 'RemoteSetup'
New-Item -ItemType Directory -Force -Path $base | Out-Null
try { Start-Transcript -Path (Join-Path $base 'setup.log') -Force | Out-Null } catch { }

Add-Type -AssemblyName System.Windows.Forms

$script:warnings = @()
$script:total = 8
function Step($n, $text) { Write-Host ''; Write-Host ('[{0}/{1}] {2}' -f $n, $script:total, $text) -ForegroundColor Cyan }
function Info($t) { Write-Host ('      ' + $t) }
function Good($t) { Write-Host ('      OK  ' + $t) -ForegroundColor Green }
function Warn($t) { Write-Host ('      LET OP  ' + $t) -ForegroundColor Yellow; $script:warnings += $t }
function Show-Box($text, $icon) {
    $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true }
    [void][System.Windows.Forms.MessageBox]::Show($owner, $text, 'PC-2 setup', 'OK', $icon)
}

Clear-Host
Write-Host '==========================================' -ForegroundColor Cyan
Write-Host '  PC-2 instellen voor bediening op afstand' -ForegroundColor Cyan
Write-Host '==========================================' -ForegroundColor Cyan
Write-Host 'Dit duurt 1 tot 3 minuten. Sluit dit venster niet.'

$ok = $true
$msg = ''

try {
    # ---------------------------------------------------------
    Step 1 'Windows controleren'
    $build = [int](Get-CimInstance Win32_OperatingSystem).BuildNumber
    if ($build -lt 17763) {
        throw 'Deze Windows-versie is te oud. Nodig: Windows 10 versie 1809 of nieuwer.'
    }
    Good ('Windows build ' + $build)

    # ---------------------------------------------------------
    Step 2 'SSH-server installeren (alleen als hij er nog niet is)'
    if (Get-Service -Name sshd -ErrorAction SilentlyContinue) {
        Good 'SSH-server is al geinstalleerd.'
    }
    else {
        $installed = $false
        $cap = Get-WindowsCapability -Online -Name 'OpenSSH.Server*' | Select-Object -First 1
        if ($cap) {
            for ($try = 1; ($try -le 2) -and (-not $installed); $try++) {
                try {
                    Info ('Installeren via Windows Update, poging ' + $try + ' (kan een paar minuten duren)...')
                    Add-WindowsCapability -Online -Name $cap.Name | Out-Null
                    $installed = [bool](Get-Service -Name sshd -ErrorAction SilentlyContinue)
                }
                catch {
                    $err = $_.Exception.Message
                    Info ('Poging ' + $try + ' mislukt: ' + $err)
                    if ($try -eq 1) {
                        Info 'Windows Update-diensten controleren en opnieuw proberen...'
                        foreach ($n in 'wuauserv', 'bits', 'cryptsvc') {
                            $sv = Get-Service -Name $n -ErrorAction SilentlyContinue
                            if ($sv) {
                                if ($sv.StartType -eq 'Disabled') { Set-Service -Name $n -StartupType Manual }
                                if ($sv.Status -ne 'Running') { Start-Service -Name $n -ErrorAction SilentlyContinue }
                            }
                        }
                    }
                }
            }
        }

        if (-not $installed) {
            Write-Host ''
            Write-Host '      Installeren via Windows Update is niet gelukt.' -ForegroundColor Yellow
            Write-Host '      Alternatief: de officiele SSH-server downloaden van GitHub' -ForegroundColor Yellow
            Write-Host '      (project PowerShell/Win32-OpenSSH, van Microsoft).' -ForegroundColor Yellow
            $a = Read-Host '      Dat doen? (j/n) [j]'
            if ($a -match '^[nN]') {
                throw 'Installatie afgebroken. Zonder SSH-server kan PC-2 niet bestuurd worden. Controleer of PC-2 internet heeft, geen datalimiet-verbinding gebruikt en dat Windows Update werkt.'
            }
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $oldProgress = $ProgressPreference
            $ProgressPreference = 'SilentlyContinue'
            Info 'Zoeken naar de nieuwste versie...'
            $rel = Invoke-RestMethod -Uri 'https://api.github.com/repos/PowerShell/Win32-OpenSSH/releases/latest' -UseBasicParsing -Headers @{ 'User-Agent' = 'remote-setup' }
            $asset = $rel.assets | Where-Object { $_.name -match '^OpenSSH-Win64-v.*\.msi$' } | Select-Object -First 1
            if (-not $asset) { throw 'Geen installatiebestand (MSI) gevonden op GitHub.' }
            $msi = Join-Path $base 'openssh.msi'
            Info ('Downloaden: ' + $asset.name)
            Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $msi -UseBasicParsing
            $ProgressPreference = $oldProgress
            Info 'Installeren...'
            $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList @('/i', ('"' + $msi + '"'), 'ADDLOCAL=Server', '/qn', '/norestart') -Wait -PassThru
            if (($p.ExitCode -ne 0) -and ($p.ExitCode -ne 3010)) {
                throw ('Installatie vanaf GitHub mislukt (foutcode ' + $p.ExitCode + ').')
            }
            Set-Content -Path (Join-Path $base 'method.txt') -Value 'msi' -Encoding ascii
            if (-not (Get-Service -Name sshd -ErrorAction SilentlyContinue)) {
                throw 'De installatie leek te lukken, maar de SSH-service ontbreekt. Herstart PC-2 en draai dit bestand opnieuw.'
            }
        }
        Good 'SSH-server geinstalleerd.'
    }

    # ---------------------------------------------------------
    Step 3 'PowerShell als standaard opdrachtvenster op PC-2 instellen'
    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    New-Item -Path 'HKLM:\SOFTWARE\OpenSSH' -Force | Out-Null
    New-ItemProperty -Path 'HKLM:\SOFTWARE\OpenSSH' -Name DefaultShell -Value $psExe -PropertyType String -Force | Out-Null
    Good 'Op afstand werken cd, ls en dir allemaal.'

    # ---------------------------------------------------------
    Step 4 'SSH-service instellen en starten'
    Set-Service -Name sshd -StartupType Automatic
    & sc.exe failure sshd reset= 86400 actions= restart/5000/restart/5000/restart/5000 | Out-Null
    if ((Get-Service -Name sshd).Status -ne 'Running') {
        try { Start-Service -Name sshd }
        catch {
            $startErr = $_.Exception.Message
            $detail = ''
            try { $detail = ((Get-WinEvent -LogName 'OpenSSH/Operational' -MaxEvents 3 | ForEach-Object { $_.Message }) -join ' | ') } catch { }
            throw ('De SSH-service kon niet starten: ' + $startErr + ' ' + $detail)
        }
    }
    (Get-Service -Name sshd).WaitForStatus('Running', [TimeSpan]::FromSeconds(20))
    Good 'sshd draait en start automatisch mee met Windows.'

    # ---------------------------------------------------------
    Step 5 'Firewall instellen'
    foreach ($n in 'OpenSSH-Server-In-TCP', 'Remote-SSH-22', 'Remote-SSH-ping') {
        Get-NetFirewallRule -Name $n -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    }
    New-NetFirewallRule -Name 'Remote-SSH-22' -DisplayName 'Remote SSH (poort 22, eigen netwerk)' `
        -Direction Inbound -Protocol TCP -LocalPort 22 -Action Allow -Profile Any `
        -RemoteAddress LocalSubnet -Enabled True | Out-Null
    New-NetFirewallRule -Name 'Remote-SSH-ping' -DisplayName 'Remote SSH (ping, eigen netwerk)' `
        -Direction Inbound -Protocol ICMPv4 -IcmpType 8 -Action Allow -Profile Any `
        -RemoteAddress LocalSubnet -Enabled True | Out-Null
    $rule = Get-NetFirewallRule -Name 'Remote-SSH-22'
    if ($rule.Enabled -ne 'True') { throw 'De firewallregel voor poort 22 kon niet worden ingeschakeld.' }
    Good 'Poort 22 is open voor je eigen thuisnetwerk (niet voor het internet).'

    # Blokkeerregels voor sshd of poort 22 opruimen (een blokkade wint altijd van een toestemming)
    foreach ($r in @(Get-NetFirewallRule -Direction Inbound -Action Block -Enabled True -ErrorAction SilentlyContinue)) {
        try {
            $prog = [string](($r | Get-NetFirewallApplicationFilter).Program)
            $pf = $r | Get-NetFirewallPortFilter
            $isSsh = ($prog -like '*\sshd.exe') -or (($pf.Protocol -eq 'TCP') -and (@($pf.LocalPort) -contains '22'))
            if ($isSsh) {
                Remove-NetFirewallRule -Name $r.Name
                Info ('Blokkeerregel verwijderd: ' + $r.DisplayName)
            }
        }
        catch { }
    }

    # Staat Windows op "alle inkomende verbindingen blokkeren"? Dan worden alle toestemmingsregels genegeerd.
    $map = @{ Public = 'Public'; Private = 'Private'; DomainAuthenticated = 'Domain' }
    foreach ($c in @(Get-NetConnectionProfile -ErrorAction SilentlyContinue)) {
        $pn = $map[[string]$c.NetworkCategory]
        if ($pn) {
            $fp = Get-NetFirewallProfile -Name $pn
            if (($fp.Enabled -eq 'True') -and ($fp.AllowInboundRules -eq 'False')) {
                Warn ('Windows Firewall blokkeert ALLE inkomende verbindingen op je ' + $pn + '-netwerk. Zet in Windows-beveiliging > Firewall en netwerkbeveiliging > je netwerk de optie "Alle binnenkomende verbindingen blokkeren" UIT, anders blijft PC-2 onbereikbaar.')
            }
        }
    }

    # Draait er een andere firewall (bijv. in een antivirusprogramma)?
    try {
        $other = @(Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName FirewallProduct -ErrorAction Stop |
            Where-Object { $_.displayName -notmatch 'Windows' } | ForEach-Object { $_.displayName })
        if ($other.Count -gt 0) {
            Warn ('Er draait ook een andere firewall: ' + ($other -join ', ') + '. Staat poort 22 daar niet open, dan blijft PC-2 onbereikbaar. Zet daar poort 22 (TCP) open voor je thuisnetwerk.')
        }
    }
    catch { }

    # ---------------------------------------------------------
    Step 6 'Slaapstand uitzetten en deksel dicht = niets doen'
    $settings = @(
        @('SUB_SLEEP', 'STANDBYIDLE'),
        @('SUB_SLEEP', 'HIBERNATEIDLE'),
        @('SUB_BUTTONS', 'LIDACTION')
    )
    function Get-Idx($sub, $set) {
        $o = (& powercfg /q SCHEME_CURRENT $sub $set | Out-String)
        $m = [regex]::Matches($o, '0x[0-9a-fA-F]{8}')
        if ($m.Count -lt 2) { return $null }
        [pscustomobject]@{
            ac = [Convert]::ToInt32($m[$m.Count - 2].Value.Substring(2), 16)
            dc = [Convert]::ToInt32($m[$m.Count - 1].Value.Substring(2), 16)
        }
    }
    $pj = Join-Path $base 'power-backup.json'
    if (-not (Test-Path $pj)) {
        $bk = @()
        foreach ($s in $settings) {
            $v = Get-Idx $s[0] $s[1]
            if ($v) { $bk += [pscustomobject]@{ sub = $s[0]; set = $s[1]; ac = $v.ac; dc = $v.dc } }
        }
        ConvertTo-Json -InputObject $bk | Set-Content -Path $pj -Encoding ascii
    }
    foreach ($s in $settings) {
        & powercfg /setacvalueindex SCHEME_CURRENT $s[0] $s[1] 0 | Out-Null
        & powercfg /setdcvalueindex SCHEME_CURRENT $s[0] $s[1] 0 | Out-Null
    }
    & powercfg /setactive SCHEME_CURRENT | Out-Null
    Good 'PC-2 gaat niet meer slapen. Laat de laptop aan de lader staan.'

    # ---------------------------------------------------------
    Step 7 'Controleren of de SSH-server echt antwoordt'
    Start-Sleep -Seconds 2
    $listen = Get-NetTCPConnection -LocalPort 22 -State Listen -ErrorAction SilentlyContinue
    if (-not $listen) {
        throw 'De SSH-service draait, maar luistert niet op poort 22. Herstart PC-2 en draai dit bestand opnieuw.'
    }
    $banner = ''
    $tc = New-Object System.Net.Sockets.TcpClient
    try {
        $tc.Connect('127.0.0.1', 22)
        $st = $tc.GetStream()
        $st.ReadTimeout = 4000
        $buf = New-Object byte[] 255
        $cnt = $st.Read($buf, 0, 255)
        if ($cnt -gt 0) { $banner = [Text.Encoding]::ASCII.GetString($buf, 0, $cnt).Trim() }
    }
    finally { $tc.Close() }
    if ($banner -notlike 'SSH-*') {
        throw 'Poort 22 is open, maar er antwoordt geen SSH-server. Herstart PC-2 en draai dit bestand opnieuw.'
    }
    Good ('De SSH-server antwoordt: ' + $banner)

    # ---------------------------------------------------------
    Step 8 'Gegevens voor PC-1 verzamelen'
    $ips = @(Get-NetIPConfiguration -ErrorAction SilentlyContinue |
        Where-Object { $_.IPv4DefaultGateway -and $_.IPv4Address -and ($_.NetAdapter.Status -eq 'Up') } |
        ForEach-Object { $_.IPv4Address.IPAddress })
    if ($ips.Count -eq 0) {
        $ips = @(Get-NetIPAddress -AddressFamily IPv4 |
            Where-Object { ($_.IPAddress -notlike '127.*') -and ($_.IPAddress -notlike '169.254.*') } |
            ForEach-Object { $_.IPAddress })
    }
    $ipText = if ($ips.Count -gt 0) { $ips -join ', ' } else { '(niet gevonden, typ ipconfig)' }

    $pwNote = 'Op PC-1 typ je het WACHTWOORD van dit Windows-account (geen pincode).'
    try {
        $lu = Get-LocalUser -Name $env:USERNAME -ErrorAction Stop
        if (($lu.PrincipalSource -eq 'Local') -and (-not $lu.PasswordLastSet)) {
            Warn 'Dit Windows-account heeft geen wachtwoord. Inloggen via SSH werkt dan niet. Stel eerst een wachtwoord in (Instellingen > Accounts > Aanmeldopties).'
        }
        if ($lu.PrincipalSource -eq 'MicrosoftAccount') {
            $pwNote = 'Dit is een Microsoft-account: op PC-1 typ je het wachtwoord van je Microsoft-account (geen pincode).'
        }
    }
    catch { }

    Info ('IP-adres: ' + $ipText)
    Info ('Gebruikersnaam: ' + $env:USERNAME)
    Info ('Computernaam: ' + $env:COMPUTERNAME)

    $msg = "PC-2 is klaar. De SSH-server draait op de achtergrond.`n`n" +
           "Vul dit in bij pc1-remote.bat op PC-1:`n`n" +
           "  IP-adres:  $ipText`n" +
           "  Gebruikersnaam:  $env:USERNAME`n" +
           "  (computernaam:  $env:COMPUTERNAME)`n`n" +
           $pwNote + "`n`n" +
           "PC-2 gaat niet meer slapen. Laat de laptop aan de lader staan."
    if ($script:warnings.Count -gt 0) {
        $msg += "`n`nLET OP:`n- " + ($script:warnings -join "`n- ")
    }
    $msg += "`n`n(Tip: Ctrl+C kopieert deze tekst.)"
}
catch {
    $ok = $false
    $msg = "Er ging iets mis:`n`n" + $_.Exception.Message + "`n`nLogbestand: " + (Join-Path $base 'setup.log')
}

try { Stop-Transcript | Out-Null } catch { }

Write-Host ''
if ($ok) {
    Write-Host 'KLAAR.' -ForegroundColor Green
    Show-Box $msg 'Information'
    exit 0
}
else {
    Write-Host $msg -ForegroundColor Red
    Show-Box $msg 'Error'
    exit 1
}
