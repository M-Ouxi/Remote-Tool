@echo off
setlocal
title Uninstall
REM ============================================================
REM  uninstall.bat  -  werkt op PC-1 en PC-2
REM  Draait alles terug wat pc1-remote.bat en pc2-server.bat deden,
REM  inclusief de slaapstand-instellingen van PC-2. Vraagt alleen om
REM  administrator-rechten als er op deze pc een SSH-server staat.
REM ============================================================

set "SELF=%~f0"
set "PS1=%TEMP%\remote-uninstall.ps1"
set "MODE=user"
if /i "%~1"=="elevated" set "MODE=server"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:SELF); $i=$s.LastIndexOf('#PS-START',[StringComparison]::Ordinal); [IO.File]::WriteAllText($env:PS1,$s.Substring($i))"
if not exist "%PS1%" goto noextract
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Mode %MODE%
set "RC=%errorlevel%"
del "%PS1%" >nul 2>&1
if not "%RC%"=="0" pause
exit /b %RC%

:noextract
echo.
echo Kon het script niet uitpakken in de map %TEMP%.
echo.
pause
exit /b 1

#PS-START
param([string]$Mode = 'user')
$ErrorActionPreference = 'SilentlyContinue'
$Host.UI.RawUI.WindowTitle = 'Uninstall'

Add-Type -AssemblyName System.Windows.Forms
function Show-Box($text) {
    $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true }
    [void][System.Windows.Forms.MessageBox]::Show($owner, $text, 'Uninstall', 'OK', 'Information')
}

$base = Join-Path $env:ProgramData 'RemoteSetup'

# ================= Deel 1: je eigen gebruikersmap (PC-1 en PC-2) =================
if ($Mode -eq 'user') {
    Write-Host 'Remote-commando verwijderen...'

    $tools = Join-Path $env:USERPROFILE 'RemoteTools'
    if (Test-Path $tools) { Remove-Item $tools -Recurse -Force }

    $p = [Environment]::GetEnvironmentVariable('Path', 'User')
    if ($p) {
        $n = (($p -split ';') | Where-Object { $_ -and ($_ -ne $tools) }) -join ';'
        [Environment]::SetEnvironmentVariable('Path', $n, 'User')
    }

    # Restanten van oudere versies van de scripts (sleutelbestanden)
    $ssh = Join-Path $env:USERPROFILE '.ssh'
    Remove-Item (Join-Path $ssh 'id_remote_pc2') -Force
    Remove-Item (Join-Path $ssh 'id_remote_pc2.pub') -Force
    $ak = Join-Path $ssh 'authorized_keys'
    if (Test-Path $ak) {
        $keep = @(Get-Content $ak | Where-Object { $_ -notmatch 'remote-pc1-setup' })
        if ($keep.Count -eq 0) { Remove-Item $ak -Force } else { Set-Content -Path $ak -Value $keep -Encoding ascii }
    }

    $serverPresent = [bool](Get-Service -Name sshd) -or (Test-Path $base)
    if (-not $serverPresent) {
        Show-Box 'Het Remote-commando is verwijderd.'
        exit 0
    }

    Write-Host 'Er staat een SSH-server op deze pc. Er wordt om administrator-rechten gevraagd om die te verwijderen...'
    Start-Process -FilePath $env:SELF -ArgumentList 'elevated' -Verb RunAs
    exit 0
}

# ================= Deel 2: SSH-server verwijderen (PC-2, administrator) =================
$Host.UI.RawUI.WindowTitle = 'Uninstall: SSH-server verwijderen'
Write-Host 'SSH-server en instellingen verwijderen. Dit kan een minuut duren...'

Write-Host '  Service stoppen...'
Stop-Service -Name sshd -Force
Set-Service -Name sshd -StartupType Disabled

Write-Host '  Firewallregels verwijderen...'
foreach ($n in 'Remote-SSH-22', 'Remote-SSH-ping', 'OpenSSH-Server-In-TCP') {
    Get-NetFirewallRule -Name $n | Remove-NetFirewallRule
}

Write-Host '  Slaapstand-instellingen terugzetten...'
$pj = Join-Path $base 'power-backup.json'
if (Test-Path $pj) {
    foreach ($b in @(Get-Content $pj -Raw | ConvertFrom-Json)) {
        & powercfg /setacvalueindex SCHEME_CURRENT $b.sub $b.set $b.ac | Out-Null
        & powercfg /setdcvalueindex SCHEME_CURRENT $b.sub $b.set $b.dc | Out-Null
    }
    & powercfg /setactive SCHEME_CURRENT | Out-Null
}

Write-Host '  Instellingen uit het register verwijderen...'
Remove-Item 'HKLM:\SOFTWARE\OpenSSH' -Recurse -Force

Write-Host '  SSH-server verwijderen...'
$method = ''
$mf = Join-Path $base 'method.txt'
if (Test-Path $mf) { $method = (Get-Content $mf -Raw).Trim() }
if ($method -eq 'msi') {
    $msi = Join-Path $base 'openssh.msi'
    if (Test-Path $msi) {
        Start-Process -FilePath 'msiexec.exe' -ArgumentList @('/x', ('"' + $msi + '"'), '/qn', '/norestart') -Wait
    }
}
else {
    Remove-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0' | Out-Null
}

Write-Host '  Restanten opruimen...'
Remove-Item (Join-Path $env:ProgramData 'ssh') -Recurse -Force
Remove-Item $base -Recurse -Force

Show-Box "De SSH-server en alle instellingen zijn verwijderd.`n`nDe slaapstand-instellingen zijn teruggezet.`nHerstart PC-2 om het verwijderen helemaal af te ronden."
exit 0
