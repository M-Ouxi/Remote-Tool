@echo off
setlocal
title PC-1: Remote-commando maken
REM ============================================================
REM  pc1-remote.bat  -  draai dit op PC-1 (de pc waarmee je bestuurt)
REM  Test of PC-2 bereikbaar is, zegt waarom niet als het niet lukt,
REM  en maakt het commando "Remote". Veilig om opnieuw te draaien.
REM ============================================================

set "SELF=%~f0"
set "PS1=%TEMP%\remote-pc1-setup.ps1"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:SELF); $i=$s.LastIndexOf('#PS-START',[StringComparison]::Ordinal); [IO.File]::WriteAllText($env:PS1,$s.Substring($i))"
if not exist "%PS1%" goto noextract
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%errorlevel%"
del "%PS1%" >nul 2>&1
if not "%RC%"=="0" pause
exit /b %RC%

:noextract
echo.
echo Kon het script niet uitpakken in de map %TEMP%.
echo.
pause
exit /b 1

#PS-START
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'PC-1: Remote-commando maken'

function Test-Ping($ip) {
    try { return [bool](Test-Connection -ComputerName $ip -Count 2 -Quiet) } catch { return $false }
}

# Probeert poort 22 te bereiken en leest de eerste regel die de SSH-server stuurt.
function Test-Ssh($ip, $ms) {
    $r = [pscustomobject]@{ State = 'timeout'; Banner = '' }
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $a = $c.BeginConnect($ip, 22, $null, $null)
        if (-not $a.AsyncWaitHandle.WaitOne($ms)) { return $r }
        try { $c.EndConnect($a) } catch { $r.State = 'refused'; return $r }
        $r.State = 'open'
        $s = $c.GetStream()
        $s.ReadTimeout = 3000
        $buf = New-Object byte[] 255
        $n = $s.Read($buf, 0, 255)
        if ($n -gt 0) { $r.Banner = [Text.Encoding]::ASCII.GetString($buf, 0, $n).Trim() }
    }
    catch { }
    finally { $c.Close() }
    return $r
}

Clear-Host
Write-Host '==========================================' -ForegroundColor Cyan
Write-Host '  PC-1: Remote-commando maken' -ForegroundColor Cyan
Write-Host '==========================================' -ForegroundColor Cyan
Write-Host ''

if (-not (Get-Command ssh.exe -ErrorAction SilentlyContinue)) {
    Write-Host 'De SSH-client is niet gevonden op deze pc.' -ForegroundColor Red
    Write-Host 'Installeer hem via Instellingen > Apps > Optionele onderdelen > OpenSSH-client.'
    exit 1
}

# ---- Eigen netwerk tonen ----
$mine = @(Get-NetIPConfiguration -ErrorAction SilentlyContinue |
    Where-Object { $_.IPv4DefaultGateway -and $_.IPv4Address } |
    ForEach-Object { $_.IPv4Address.IPAddress })
if ($mine.Count -gt 0) {
    Write-Host ('Het IP-adres van deze pc (PC-1): ' + ($mine -join ', '))
    Write-Host 'Het IP-adres van PC-2 moet met (bijna) dezelfde cijfers beginnen, bijvoorbeeld beide 192.168.1.x.'
    Write-Host ''
}
Write-Host 'Typ het IP-adres uit de melding die pc2-server.bat op PC-2 liet zien.'
Write-Host ''

# ---- Gegevens van PC-2 vragen ----
do {
    $pc = (Read-Host 'IP-adres of computernaam van PC-2').Trim()
    $user = (Read-Host 'Gebruikersnaam op PC-2').Trim()
    $candidates = @()
    if (-not $pc -or -not $user) {
        Write-Host 'Vul beide velden in.' -ForegroundColor Yellow
        continue
    }
    $parsed = $null
    if ([System.Net.IPAddress]::TryParse($pc, [ref]$parsed) -and ($parsed.AddressFamily -eq 'InterNetwork')) {
        $candidates = @($pc)
    }
    else {
        try {
            $candidates = @([System.Net.Dns]::GetHostAddresses($pc) |
                Where-Object { $_.AddressFamily -eq 'InterNetwork' } |
                ForEach-Object { $_.ToString() })
        }
        catch { }
        if ($candidates.Count -eq 0) {
            Write-Host ("De naam '" + $pc + "' kan niet worden gevonden. Gebruik het IP-adres van PC-2.") -ForegroundColor Yellow
        }
    }
    Write-Host ''
} while ($candidates.Count -eq 0)

# ---- Verbinding testen ----
Write-Host 'Verbinding testen...' -ForegroundColor Cyan
$chosen = $null
$firstPing = $false
$firstState = 'timeout'
$idx = 0
foreach ($ip in $candidates) {
    Write-Host ('  ' + $ip)
    $ping = Test-Ping $ip
    $ssh = Test-Ssh $ip 5000
    if ($ping) { Write-Host '    ping:      antwoord ontvangen' -ForegroundColor Green }
    else { Write-Host '    ping:      geen antwoord' -ForegroundColor Yellow }
    if (($ssh.State -eq 'open') -and ($ssh.Banner -like 'SSH-*')) {
        Write-Host ('    poort 22:  open, SSH-server antwoordt (' + $ssh.Banner + ')') -ForegroundColor Green
        $chosen = $ip
        break
    }
    elseif ($ssh.State -eq 'open') { Write-Host '    poort 22:  open, maar er antwoordt geen SSH-server' -ForegroundColor Yellow }
    elseif ($ssh.State -eq 'refused') { Write-Host '    poort 22:  geweigerd (PC-2 is bereikbaar, maar er draait geen SSH-server)' -ForegroundColor Yellow }
    else { Write-Host '    poort 22:  geen antwoord (time-out)' -ForegroundColor Yellow }
    if ($idx -eq 0) { $firstPing = $ping; $firstState = $ssh.State }
    $idx++
}

if ($chosen) {
    $target = $chosen
    Write-Host ''
    Write-Host 'PC-2 is bereikbaar en de SSH-server werkt.' -ForegroundColor Green
}
else {
    $target = $candidates[0]
    Write-Host ''
    Write-Host 'PC-2 is NIET bereikbaar via SSH. Waarschijnlijke oorzaak:' -ForegroundColor Red
    if ($firstState -eq 'refused') {
        Write-Host '  De SSH-server draait niet. Draai pc2-server.bat op PC-2 en wacht op de melding "PC-2 is klaar".'
    }
    elseif ($firstPing) {
        Write-Host '  PC-2 is wel bereikbaar (ping werkt), maar poort 22 wordt geblokkeerd.'
        Write-Host '  Draai pc2-server.bat opnieuw op PC-2 en lees de LET OP-regels in de melding.'
        Write-Host '  Vaak is het een andere firewall of antivirus op PC-2, of "Alle binnenkomende verbindingen blokkeren".'
    }
    else {
        Write-Host '  PC-2 reageert helemaal niet. Controleer:'
        Write-Host '   - Staat PC-2 aan en niet in slaapstand? Draai anders pc2-server.bat nog een keer.'
        Write-Host '   - Klopt het IP-adres? Typ ipconfig op PC-2.'
        Write-Host '   - Zitten beide pc''s op hetzelfde netwerk (geen gastnetwerk, geen VPN aan)?'
        Write-Host '   - Heb je pc2-server.bat op PC-2 gedraaid en de melding "PC-2 is klaar" gezien?'
        Write-Host '   - Oudere versie van pc2-server.bat gebruikt? Dan blokkeert PC-2 ook ping; draai de nieuwe versie.'
    }
    Write-Host ''
    $a = Read-Host 'Het Remote-commando toch aanmaken? (j/n) [j]'
    if ($a -match '^[nN]') { exit 1 }
}

# ---- Remote.cmd aanmaken ----
$tools = Join-Path $env:USERPROFILE 'RemoteTools'
New-Item -ItemType Directory -Force -Path $tools | Out-Null
$kh = Join-Path $tools 'known_hosts'
if (Test-Path $kh) { Remove-Item $kh -Force }

$line = 'ssh -4 -o ConnectTimeout=8 -o ServerAliveInterval=30 -o StrictHostKeyChecking=accept-new -o "UserKnownHostsFile=%~dp0known_hosts" -l "' + $user + '" ' + $target + ' %*'
Set-Content -Path (Join-Path $tools 'Remote.cmd') -Value ("@echo off`r`n" + $line + "`r`n") -Encoding ascii

# ---- Map aan gebruikers-PATH toevoegen ----
$p = [Environment]::GetEnvironmentVariable('Path', 'User')
if (-not $p) { $p = '' }
if (($p -split ';') -notcontains $tools) {
    [Environment]::SetEnvironmentVariable('Path', ($p.TrimEnd(';') + ';' + $tools).TrimStart(';'), 'User')
}

Write-Host ''
Write-Host 'Het commando "Remote" is aangemaakt.' -ForegroundColor Green
Write-Host ''

# ---- Direct testen ----
$go = Read-Host 'Nu meteen verbinden met PC-2 om te testen? (j/n) [j]'
if ($go -notmatch '^[nN]') {
    Write-Host ''
    Write-Host 'Typ het WACHTWOORD van het Windows-account op PC-2 (geen pincode). Typ "exit" om terug te gaan naar PC-1.' -ForegroundColor Cyan
    Write-Host ''
    & (Join-Path $tools 'Remote.cmd')
    Write-Host ''
    if ($LASTEXITCODE -eq 255) {
        Write-Host 'Verbinden of inloggen is niet gelukt. Lees de melding hierboven:' -ForegroundColor Yellow
        Write-Host '  - "Permission denied": gebruik de naam van het account op PC-2 (typ whoami op PC-2, het deel na de \),'
        Write-Host '    niet je e-mailadres, en typ het wachtwoord, niet de pincode. Heeft het account geen wachtwoord, maak er dan een aan.'
        Write-Host '  - "Connection timed out": zie de tips hierboven; draai pc2-server.bat opnieuw.'
        Write-Host '  - "HOST IDENTIFICATION HAS CHANGED": draai dit bestand (pc1-remote.bat) gewoon opnieuw.'
    }
}

Write-Host ''
Write-Host '==========================================' -ForegroundColor Green
Write-Host '  Gebruik' -ForegroundColor Green
Write-Host '==========================================' -ForegroundColor Green
Write-Host '  Open een NIEUWE terminal en typ:'
Write-Host ''
Write-Host '      Remote' -ForegroundColor Cyan
Write-Host ''
Write-Host '  Je zit dan in PC-2. cd, ls en dir werken allemaal. Typ "exit" om terug te gaan.'
Write-Host '  Los commando zonder sessie, bijvoorbeeld:'
Write-Host '      Remote ls C:\Users' -ForegroundColor Cyan
Write-Host ''
Write-Host '  Verandert het IP-adres van PC-2 of heb je PC-2 opnieuw ingesteld? Draai dit bestand dan opnieuw.'
Write-Host ''
[void](Read-Host 'Druk op Enter om te sluiten')
exit 0
