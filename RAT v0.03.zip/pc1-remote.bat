@echo off
REM ============================================================
REM  pc1-remote.bat  -  draai dit op PC-1 (de pc waarmee je bestuurt)
REM  Maakt het commando "Remote" dat verbindt met PC-2.
REM  Test de verbinding en kan inloggen zonder wachtwoord instellen.
REM  Veilig om opnieuw te draaien (bijv. als het IP-adres verandert).
REM ============================================================

powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText('%~f0'); Invoke-Expression $s.Substring($s.LastIndexOf('#PS-START',[StringComparison]::Ordinal))"
exit /b

#PS-START
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'PC-1: Remote-commando maken'

function Pause-End {
    Write-Host ''
    [void](Read-Host 'Druk op Enter om te sluiten')
    exit
}

function Test-Port($h, $port, $ms) {
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $a = $c.BeginConnect($h, $port, $null, $null)
        if ($a.AsyncWaitHandle.WaitOne($ms)) { $c.EndConnect($a); return $true }
        return $false
    }
    catch { return $false }
    finally { $c.Close() }
}

Clear-Host
Write-Host '=== PC-1: Remote-commando maken ===' -ForegroundColor Cyan
Write-Host ''

if (-not (Get-Command ssh.exe -ErrorAction SilentlyContinue)) {
    Write-Host 'De SSH-client is niet gevonden op deze pc.' -ForegroundColor Red
    Write-Host 'Installeer hem via Instellingen > Apps > Optionele onderdelen > OpenSSH-client.'
    Pause-End
}

# ---- Gegevens van PC-2 ----
Write-Host 'Tip: gebruik het IP-adres, dat is betrouwbaarder dan de computernaam.'
Write-Host ''
do {
    $pc = (Read-Host 'IP-adres of computernaam van PC-2 (bijv. 192.168.1.50)').Trim()
    $user = (Read-Host 'Gebruikersnaam op PC-2').Trim()
    if (-not $pc -or -not $user) { Write-Host 'Vul beide velden in.' -ForegroundColor Yellow }
} while (-not $pc -or -not $user)

# ---- Verbinding testen ----
Write-Host ''
Write-Host "Verbinding testen met $pc (poort 22)..."
$reachable = Test-Port $pc 22 5000
if ($reachable) {
    Write-Host 'PC-2 is bereikbaar.' -ForegroundColor Green
}
else {
    Write-Host 'PC-2 is NIET bereikbaar op poort 22.' -ForegroundColor Red
    try { [void][System.Net.Dns]::GetHostAddresses($pc) }
    catch { Write-Host "De naam '$pc' is niet gevonden. Gebruik het IP-adres van PC-2." -ForegroundColor Yellow }
    Write-Host ''
    Write-Host 'Controleer:'
    Write-Host '  - Heb je pc2-server.bat op PC-2 gedraaid en kreeg je de melding "PC-2 is klaar"?'
    Write-Host '  - Staat PC-2 aan (niet in slaapstand) en zit hij op hetzelfde netwerk als deze pc?'
    Write-Host '  - Klopt het IP-adres? Typ ipconfig op PC-2.'
    Write-Host ''
    Write-Host 'Het Remote-commando wordt toch aangemaakt, zodat je het later opnieuw kunt proberen.'
}

# ---- Optioneel: inloggen zonder wachtwoord ----
$sshDir = Join-Path $env:USERPROFILE '.ssh'
$keyPath = Join-Path $sshDir 'id_remote_pc2'
$useKey = $false

if ($reachable) {
    Write-Host ''
    $ans = Read-Host 'Inloggen zonder wachtwoord instellen? Je typt nu eenmalig het wachtwoord van PC-2 (j/n) [j]'
    if ($ans -notmatch '^[nN]') {
        try {
            New-Item -ItemType Directory -Force -Path $sshDir | Out-Null
            if (-not (Test-Path $keyPath)) {
                & ssh-keygen.exe -q -t ed25519 -N '""' -C 'remote-pc1-setup' -f $keyPath
                if (-not (Test-Path $keyPath)) { throw 'Sleutel aanmaken is mislukt.' }
            }
            $pub = (Get-Content "$keyPath.pub" -Raw).Trim()

            $remoteScript = @'
$k = '__KEY__'
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin = (New-Object Security.Principal.WindowsPrincipal $id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($isAdmin) {
    $f = Join-Path $env:ProgramData 'ssh\administrators_authorized_keys'
} else {
    $d = Join-Path $env:USERPROFILE '.ssh'
    New-Item -ItemType Directory -Force -Path $d | Out-Null
    $f = Join-Path $d 'authorized_keys'
}
if (-not (Test-Path $f)) { New-Item -ItemType File -Force -Path $f | Out-Null }
if (-not (Select-String -Path $f -SimpleMatch -Pattern $k -Quiet)) { Add-Content -Path $f -Value $k -Encoding ascii }
if ($isAdmin) { icacls.exe $f /inheritance:r /grant '*S-1-5-32-544:F' /grant '*S-1-5-18:F' | Out-Null }
'@
            $remoteScript = $remoteScript.Replace('__KEY__', $pub)
            $enc = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($remoteScript))

            Write-Host ''
            Write-Host "Typ het wachtwoord van $user op PC-2 als erom gevraagd wordt..." -ForegroundColor Cyan
            & ssh.exe -o ConnectTimeout=8 -o StrictHostKeyChecking=accept-new "$user@$pc" "powershell -NoProfile -EncodedCommand $enc"

            # Testen of de sleutel werkt (zonder wachtwoord)
            & ssh.exe -o BatchMode=yes -o ConnectTimeout=8 -o StrictHostKeyChecking=accept-new -i $keyPath "$user@$pc" 'exit' 2>$null
            if ($LASTEXITCODE -eq 0) {
                $useKey = $true
                Write-Host 'Inloggen zonder wachtwoord werkt.' -ForegroundColor Green
            }
            else {
                Write-Host 'Inloggen zonder wachtwoord is niet gelukt. Je kunt wel gewoon met wachtwoord inloggen.' -ForegroundColor Yellow
            }
        }
        catch {
            Write-Host ('Sleutel instellen is niet gelukt: ' + $_.Exception.Message) -ForegroundColor Yellow
            Write-Host 'Je kunt wel gewoon met wachtwoord inloggen.'
        }
    }
}

# ---- Remote.cmd aanmaken ----
$tools = Join-Path $env:USERPROFILE 'RemoteTools'
New-Item -ItemType Directory -Force -Path $tools | Out-Null

$line = 'ssh -o ConnectTimeout=8 -o ServerAliveInterval=30 -o StrictHostKeyChecking=accept-new'
if ($useKey) { $line += " -i `"$keyPath`"" }
$line += " $user@$pc %*"
Set-Content -Path (Join-Path $tools 'Remote.cmd') -Value ("@echo off`r`n" + $line + "`r`n") -Encoding ascii

# ---- Map aan gebruikers-PATH toevoegen ----
$p = [Environment]::GetEnvironmentVariable('Path', 'User')
if (-not $p) { $p = '' }
if (($p -split ';') -notcontains $tools) {
    [Environment]::SetEnvironmentVariable('Path', ($p.TrimEnd(';') + ';' + $tools).TrimStart(';'), 'User')
}

Write-Host ''
Write-Host '==========================================' -ForegroundColor Green
Write-Host '  Klaar!' -ForegroundColor Green
Write-Host '==========================================' -ForegroundColor Green
Write-Host '  Open een NIEUWE terminal en typ:'
Write-Host ''
Write-Host '      Remote' -ForegroundColor Cyan
Write-Host ''
Write-Host '  Je zit dan in PC-2. cd, ls en dir werken allemaal.'
Write-Host '  Typ "exit" om terug te gaan naar PC-1.'
Write-Host ''
Write-Host '  Los commando zonder sessie, bijvoorbeeld:'
Write-Host '      Remote ls C:\Users' -ForegroundColor Cyan
if (-not $useKey) {
    Write-Host ''
    Write-Host '  Je typt bij elke verbinding het Windows-wachtwoord van PC-2.'
}
Pause-End
