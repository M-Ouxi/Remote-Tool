@echo off
REM ============================================================
REM  pc2-server.bat  -  draai dit op PC-2 (de pc die bestuurd wordt)
REM  Dubbelklik en bevestig de admin-vraag. Alles gebeurt op de
REM  achtergrond. Aan het eind krijg je 1 melding met het resultaat
REM  en de gegevens die je op PC-1 nodig hebt.
REM  Veilig om opnieuw te draaien.
REM ============================================================

net session >nul 2>&1
if errorlevel 1 goto elevate

powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "$s=[IO.File]::ReadAllText('%~f0'); Invoke-Expression $s.Substring($s.LastIndexOf('#PS-START',[StringComparison]::Ordinal))"
exit /b

:elevate
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs -WindowStyle Hidden"
exit /b

#PS-START
$ErrorActionPreference = 'Stop'

$base = Join-Path $env:ProgramData 'RemoteSetup'
New-Item -ItemType Directory -Force -Path $base | Out-Null
try { Start-Transcript -Path (Join-Path $base 'setup.log') -Force | Out-Null } catch {}

Add-Type -AssemblyName System.Windows.Forms
function Show-Box($text, $icon) {
    $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true }
    [void][System.Windows.Forms.MessageBox]::Show($owner, $text, 'PC-2 setup', 'OK', $icon)
}

$ok = $true
$msg = ''

try {
    # 1. Windows-versie controleren
    $build = [int](Get-CimInstance Win32_OperatingSystem).BuildNumber
    if ($build -lt 17763) {
        throw 'Deze Windows-versie is te oud. Nodig: Windows 10 versie 1809 of nieuwer.'
    }

    # 2. OpenSSH-server installeren (alleen als hij er nog niet is)
    $cap = Get-WindowsCapability -Online -Name 'OpenSSH.Server*' | Select-Object -First 1
    if (-not $cap) { throw 'OpenSSH-server is niet beschikbaar in deze Windows-versie.' }
    if ($cap.State -ne 'Installed') {
        Add-WindowsCapability -Online -Name $cap.Name | Out-Null
        $cap = Get-WindowsCapability -Online -Name $cap.Name
        if ($cap.State -ne 'Installed') {
            throw 'Installatie van de OpenSSH-server is niet gelukt. Controleer of PC-2 internet heeft en Windows Update werkt.'
        }
    }

    # 3. Standaard shell op PC-2 = PowerShell (dan werken cd, ls en dir allemaal)
    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    New-Item -Path 'HKLM:\SOFTWARE\OpenSSH' -Force | Out-Null
    New-ItemProperty -Path 'HKLM:\SOFTWARE\OpenSSH' -Name DefaultShell -Value $psExe -PropertyType String -Force | Out-Null

    # 4. Service: automatisch starten, bij crash vanzelf herstarten
    Set-Service -Name sshd -StartupType Automatic
    & sc.exe failure sshd reset= 86400 actions= restart/5000/restart/5000/restart/5000 | Out-Null
    if ((Get-Service sshd).Status -ne 'Running') { Start-Service sshd }
    (Get-Service sshd).WaitForStatus('Running', [TimeSpan]::FromSeconds(20))

    # 5. Firewall: poort 22 open, maar alleen voor je eigen thuisnetwerk
    Get-NetFirewallRule -Name 'OpenSSH-Server-In-TCP' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    Get-NetFirewallRule -Name 'Remote-SSH-22' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    New-NetFirewallRule -Name 'Remote-SSH-22' -DisplayName 'Remote SSH (poort 22, alleen eigen netwerk)' `
        -Direction Inbound -Protocol TCP -LocalPort 22 -Action Allow -Profile Any `
        -RemoteAddress LocalSubnet -Enabled True | Out-Null

    # 6. Slaapstand uit en deksel dicht = niets doen (oude waarden worden bewaard voor uninstall.bat)
    $settings = @(
        @('SUB_SLEEP', 'STANDBYIDLE'),
        @('SUB_SLEEP', 'HIBERNATEIDLE'),
        @('SUB_BUTTONS', 'LIDACTION')
    )
    function Get-Idx($sub, $set) {
        $o = (& powercfg /q SCHEME_CURRENT $sub $set | Out-String)
        $m = [regex]::Matches($o, '0x[0-9a-fA-F]{8}')
        if ($m.Count -lt 2) { return $null }
        [pscustomobject]@{
            ac = [Convert]::ToInt32($m[$m.Count - 2].Value.Substring(2), 16)
            dc = [Convert]::ToInt32($m[$m.Count - 1].Value.Substring(2), 16)
        }
    }
    $pj = Join-Path $base 'power-backup.json'
    if (-not (Test-Path $pj)) {
        $bk = @()
        foreach ($s in $settings) {
            $v = Get-Idx $s[0] $s[1]
            if ($v) { $bk += [pscustomobject]@{ sub = $s[0]; set = $s[1]; ac = $v.ac; dc = $v.dc } }
        }
        ConvertTo-Json -InputObject $bk | Set-Content -Path $pj -Encoding ascii
    }
    foreach ($s in $settings) {
        & powercfg /setacvalueindex SCHEME_CURRENT $s[0] $s[1] 0 | Out-Null
        & powercfg /setdcvalueindex SCHEME_CURRENT $s[0] $s[1] 0 | Out-Null
    }
    & powercfg /setactive SCHEME_CURRENT | Out-Null

    # 7. Controle: luistert de server echt op poort 22?
    Start-Sleep -Seconds 2
    $listen = Get-NetTCPConnection -LocalPort 22 -State Listen -ErrorAction SilentlyContinue
    if (-not $listen) {
        throw 'De SSH-service draait, maar luistert niet op poort 22. Herstart PC-2 en draai dit bestand opnieuw.'
    }

    # 8. Gegevens voor PC-1 verzamelen
    $ips = @(Get-NetIPConfiguration |
        Where-Object { $_.IPv4DefaultGateway -and $_.IPv4Address -and $_.NetAdapter.Status -eq 'Up' } |
        ForEach-Object { $_.IPv4Address.IPAddress })
    if ($ips.Count -eq 0) {
        $ips = @(Get-NetIPAddress -AddressFamily IPv4 |
            Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
            ForEach-Object { $_.IPAddress })
    }
    $ipText = if ($ips.Count -gt 0) { $ips -join ', ' } else { '(niet gevonden, typ ipconfig)' }

    $msg = "PC-2 is klaar. De SSH-server draait op de achtergrond.`n`n" +
           "Vul dit in bij pc1-remote.bat op PC-1:`n`n" +
           "  Gebruikersnaam:  $env:USERNAME`n" +
           "  IP-adres:  $ipText`n" +
           "  (of computernaam:  $env:COMPUTERNAME)`n`n" +
           "Slaapstand staat uit en 'deksel dicht' doet niets meer. Laat de laptop aan de lader.`n`n" +
           "(Tip: Ctrl+C kopieert deze tekst.)"
}
catch {
    $ok = $false
    $msg = "Er ging iets mis:`n`n" + $_.Exception.Message + "`n`nLogbestand: $base\setup.log"
}

try { Stop-Transcript | Out-Null } catch {}
if ($ok) { Show-Box $msg 'Information' } else { Show-Box $msg 'Error' }
