@echo off
REM ============================================================
REM  uninstall.bat  -  werkt op PC-1 en PC-2
REM  Draait alles terug wat pc1-remote.bat en pc2-server.bat hebben
REM  gedaan, inclusief de slaapstand-instellingen van PC-2.
REM  Vraagt alleen om admin als er op deze pc een SSH-server staat.
REM ============================================================

powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "$bat='%~f0'; $a='%~1'; $s=[IO.File]::ReadAllText($bat); Invoke-Expression $s.Substring($s.LastIndexOf('#PS-START',[StringComparison]::Ordinal))"
exit /b

#PS-START
$ErrorActionPreference = 'SilentlyContinue'

Add-Type -AssemblyName System.Windows.Forms
function Show-Box($text) {
    $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true }
    [void][System.Windows.Forms.MessageBox]::Show($owner, $text, 'Uninstall', 'OK', 'Information')
}

# ---- Deel 1 (PC-1 en PC-2): dingen in je eigen gebruikersmap ----
if ($a -ne 'admin') {
    $tools = Join-Path $env:USERPROFILE 'RemoteTools'
    if (Test-Path $tools) { Remove-Item $tools -Recurse -Force }

    $p = [Environment]::GetEnvironmentVariable('Path', 'User')
    if ($p) {
        $n = (($p -split ';') | Where-Object { $_ -and $_ -ne $tools }) -join ';'
        [Environment]::SetEnvironmentVariable('Path', $n, 'User')
    }

    $ssh = Join-Path $env:USERPROFILE '.ssh'
    Remove-Item (Join-Path $ssh 'id_remote_pc2') -Force
    Remove-Item (Join-Path $ssh 'id_remote_pc2.pub') -Force

    # Sleutel van PC-1 uit authorized_keys halen (alleen relevant op PC-2, niet-admin account)
    $ak = Join-Path $ssh 'authorized_keys'
    if (Test-Path $ak) {
        $keep = @(Get-Content $ak | Where-Object { $_ -notmatch 'remote-pc1-setup' })
        if ($keep.Count -eq 0) { Remove-Item $ak -Force } else { Set-Content -Path $ak -Value $keep -Encoding ascii }
    }
}

# ---- Staat er een SSH-server op deze pc? Zo niet: klaar ----
if (-not (Get-Service sshd)) {
    if ($a -ne 'admin') { Show-Box 'Het Remote-commando is verwijderd.' }
    exit
}

# ---- Admin nodig voor de rest ----
$isAdmin = (New-Object Security.Principal.WindowsPrincipal ([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process -FilePath $bat -ArgumentList 'admin' -Verb RunAs -WindowStyle Hidden
    exit
}

# ---- Deel 2 (PC-2): SSH-server en instellingen verwijderen ----
Stop-Service sshd -Force
Set-Service sshd -StartupType Disabled
Remove-NetFirewallRule -Name 'Remote-SSH-22'
Remove-NetFirewallRule -Name 'OpenSSH-Server-In-TCP'

# Slaapstand-instellingen terugzetten
$base = Join-Path $env:ProgramData 'RemoteSetup'
$pj = Join-Path $base 'power-backup.json'
if (Test-Path $pj) {
    foreach ($b in @(Get-Content $pj -Raw | ConvertFrom-Json)) {
        & powercfg /setacvalueindex SCHEME_CURRENT $b.sub $b.set $b.ac | Out-Null
        & powercfg /setdcvalueindex SCHEME_CURRENT $b.sub $b.set $b.dc | Out-Null
    }
    & powercfg /setactive SCHEME_CURRENT | Out-Null
}

Remove-Item 'HKLM:\SOFTWARE\OpenSSH' -Recurse -Force
Remove-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0' | Out-Null
Remove-Item (Join-Path $env:ProgramData 'ssh') -Recurse -Force
Remove-Item $base -Recurse -Force

Show-Box "De SSH-server en alle instellingen zijn verwijderd.`n`nDe slaapstand-instellingen zijn teruggezet.`nHerstart PC-2 om het verwijderen helemaal af te ronden."
