#!/bin/bash
# ============================================================
#  mac-server.command  -  draai dit op de Mac (de pc die bestuurd wordt)
#
#  Zo start je het (de makkelijkste manier):
#    1. Open Terminal (Spotlight: Cmd+Spatie, typ "Terminal").
#    2. Typ:  bash   (met een spatie erachter)
#    3. Sleep dit bestand in het Terminal-venster en druk op Enter.
#
#  Je typt 1 keer het wachtwoord van deze Mac (de normale beheerdersvraag
#  van macOS, je ziet de letters niet verschijnen). Geen code, geen extra
#  account: dit bestand en pc1-remote-mac.bat horen bij elkaar en laten
#  PC-1 er automatisch bij zonder wachtwoord. Geef deze bestanden dus
#  NOOIT aan iemand anders; wie ze heeft, kan bij deze Mac.
#  Veilig om opnieuw te draaien.
# ============================================================

# Publieke helft van de sleutel die bij pc1-remote-mac.bat hoort.
PUBKEY='ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDXz1jjOXN/lr3rtyEw02VnIhW8wpd8uZhVUAq0o9byV remote-shared'

ME="$(id -un)"
BASE="$HOME/Library/Application Support/RemoteSetup"
STATE="$BASE/state.env"
AK="$HOME/.ssh/authorized_keys"
TOTAL=8
WARNINGS=()

C_CYAN=$'\033[36m'; C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'; C_RED=$'\033[31m'; C_OFF=$'\033[0m'
step() { printf '\n%s[%s/%s] %s%s\n' "$C_CYAN" "$1" "$TOTAL" "$2" "$C_OFF"; }
info() { printf '      %s\n' "$1"; }
good() { printf '      %sOK%s  %s\n' "$C_GREEN" "$C_OFF" "$1"; }
warn() { printf '      %sLET OP%s  %s\n' "$C_YELLOW" "$C_OFF" "$1"; WARNINGS+=("$1"); }
note() { printf '      %s%s%s\n' "$C_YELLOW" "$1" "$C_OFF"; }

popup() {
  osascript - "$1" "$2" >/dev/null 2>&1 <<'APPLESCRIPT'
on run argv
  set theText to item 1 of argv
  set theIcon to item 2 of argv
  if theIcon is "stop" then
    display dialog theText with title "Mac instellen" buttons {"OK"} default button 1 with icon stop
  else
    display dialog theText with title "Mac instellen" buttons {"OK"} default button 1 with icon note
  end if
end run
APPLESCRIPT
}

fail() {
  printf '\n%sEr ging iets mis:%s\n%s\n\n' "$C_RED" "$C_OFF" "$1"
  popup "Er ging iets mis:

$1" "stop"
  exit 1
}

get_state() { [ -f "$STATE" ] && grep "^$1=" "$STATE" | head -n 1 | cut -d= -f2-; }
set_state() {
  mkdir -p "$BASE"; touch "$STATE"
  grep -v "^$1=" "$STATE" > "$STATE.tmp" 2>/dev/null
  echo "$1=$2" >> "$STATE.tmp"
  mv "$STATE.tmp" "$STATE"
}

is_listening() { nc -z -w 2 127.0.0.1 22 >/dev/null 2>&1; }
wait_listening() { local i; for i in 1 2 3 4 5 6 7 8; do is_listening && return 0; sleep 1; done; return 1; }

# Leest de 'sleep'-instelling (minuten) voor "Battery Power" of "AC Power"
get_sleep() {
  pmset -g custom 2>/dev/null | awk -v sec="$1:" '
    index($0, sec) == 1 { f = 1; next }
    /Power:/ { f = 0 }
    f && $1 == "sleep" { print $2; exit }'
}

# --- Zelftest: kan een SSH-verbinding op afstand bij Bureaublad, Documenten en Downloads? ---
# We loggen daarvoor in op deze Mac zelf, via SSH, met een wegwerpsleutel. Zo gaat de test
# door dezelfde macOS-beveiliging als een verbinding van PC-1. De wegwerpsleutel wordt
# direct daarna weer verwijderd.
SELFTEST_DIR=''
TCC_RESULT=''
cleanup_selftest() {
  if [ -n "$SELFTEST_DIR" ]; then
    if [ -f "$AK" ]; then
      grep -v 'remote-selftest' "$AK" > "$AK.tmp" 2>/dev/null
      mv "$AK.tmp" "$AK"
      chmod 600 "$AK"
    fi
    rm -rf "$SELFTEST_DIR"
    SELFTEST_DIR=''
  fi
}
trap cleanup_selftest EXIT

check_remote_access() {
  TCC_RESULT='UNKNOWN'
  SELFTEST_DIR="$(mktemp -d)"
  ssh-keygen -q -t ed25519 -N '' -C remote-selftest -f "$SELFTEST_DIR/k" >/dev/null 2>&1 || { cleanup_selftest; return; }
  mkdir -p "$HOME/.ssh"; touch "$AK"
  if [ -s "$AK" ] && [ -n "$(tail -c1 "$AK")" ]; then echo >> "$AK"; fi
  cat "$SELFTEST_DIR/k.pub" >> "$AK"
  chmod 600 "$AK"
  local out
  out="$(ssh -i "$SELFTEST_DIR/k" -o IdentitiesOnly=yes -o BatchMode=yes -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o ConnectTimeout=6 "$ME@127.0.0.1" \
        'ls "$HOME/Desktop" >/dev/null 2>&1 && echo TCC_OK || echo TCC_NO' 2>/dev/null | tail -n 1)"
  cleanup_selftest
  case "$out" in
    TCC_OK|TCC_NO) TCC_RESULT="$out" ;;
  esac
}

clear
printf '%s==========================================\n  Mac instellen voor bediening op afstand\n==========================================%s\n' "$C_CYAN" "$C_OFF"
echo 'Dit duurt ongeveer een minuut.'

if [ "$(id -u)" -eq 0 ]; then
  fail 'Draai dit bestand NIET met sudo of als root. Start het gewoon als jezelf; het vraagt zelf om het wachtwoord als dat nodig is.'
fi

# ---------------------------------------------------------
step 1 'Beheerdersrechten controleren'
if ! id -Gn | tr ' ' '\n' | grep -qx admin; then
  fail "Het account '$ME' is geen beheerder van deze Mac. Log in met een beheerdersaccount en draai dit bestand opnieuw."
fi
echo
info 'macOS vraagt nu om het wachtwoord van deze Mac (je ziet niets verschijnen).'
if ! sudo -v; then
  fail 'Het wachtwoord werd niet geaccepteerd, of je hebt geannuleerd. Draai dit bestand opnieuw.'
fi
good "Beheerder: $ME"

# ---------------------------------------------------------
step 2 'Externe login (SSH) aanzetten'
if is_listening; then
  good 'Externe login stond al aan.'
  [ -z "$(get_state REMOTELOGIN_BY_SCRIPT)" ] && set_state REMOTELOGIN_BY_SCRIPT 0
else
  info 'Aanzetten via Terminal...'
  sudo systemsetup -setremotelogin on >/dev/null 2>&1
  wait_listening
  if ! is_listening; then
    info 'Eerste methode werkte niet, tweede methode proberen...'
    sudo launchctl load -w /System/Library/LaunchDaemons/ssh.plist >/dev/null 2>&1
    wait_listening
  fi
  if ! is_listening; then
    echo
    note 'Terminal mag dit op jouw Mac niet zelf aanzetten. Zet het in de Instellingen aan (10 seconden werk):'
    info '1. Het venster Instellingen opent nu vanzelf (Algemeen > Delen).'
    info '2. Zet "Externe login" AAN.'
    info '3. Kom terug naar dit venster en druk op Enter.'
    open 'x-apple.systempreferences:com.apple.Sharing-Settings.extension' >/dev/null 2>&1 \
      || open 'x-apple.systempreferences:com.apple.preferences.sharing' >/dev/null 2>&1
    read -r -p '      Druk op Enter zodra Externe login aan staat... ' _
    wait_listening
  fi
  is_listening || fail 'Externe login staat nog niet aan. Zet in Instellingen > Algemeen > Delen "Externe login" aan en draai dit bestand opnieuw.'
  [ -z "$(get_state REMOTELOGIN_BY_SCRIPT)" ] && set_state REMOTELOGIN_BY_SCRIPT 1
  good 'Externe login staat aan.'
fi

# Mag dit account inloggen? (Alleen relevant als "Alleen deze gebruikers" is ingesteld.)
if dscl . -read /Groups/com.apple.access_ssh >/dev/null 2>&1; then
  if ! dseditgroup -o checkmember -m "$ME" com.apple.access_ssh >/dev/null 2>&1; then
    if sudo dseditgroup -o edit -a "$ME" -t user com.apple.access_ssh >/dev/null 2>&1; then
      [ -z "$(get_state GROUP_ADDED)" ] && set_state GROUP_ADDED 1
      info "Account '$ME' toegevoegd aan de lijst met toegestane gebruikers."
    else
      warn "Kon '$ME' niet toevoegen aan de lijst met toegestane gebruikers. Voeg het account zelf toe via Instellingen > Algemeen > Delen > Externe login (i)."
    fi
  fi
fi

# ---------------------------------------------------------
step 3 'Sleutel van PC-1 toelaten (geen wachtwoord nodig, geen extra account)'
mkdir -p "$HOME/.ssh"
chmod 700 "$HOME/.ssh"
AK="$HOME/.ssh/authorized_keys"
touch "$AK"
if [ -s "$AK" ] && [ -n "$(tail -c1 "$AK")" ]; then echo >> "$AK"; fi
if grep -qxF "$PUBKEY" "$AK"; then
  info 'De sleutel stond er al.'
else
  echo "$PUBKEY" >> "$AK"
fi
chmod 600 "$AK"
chmod go-w "$HOME" 2>/dev/null
good 'PC-1 mag er automatisch bij, zonder wachtwoord.'

# ---------------------------------------------------------
step 4 'Firewall controleren'
FW=/usr/libexec/ApplicationFirewall/socketfilterfw
if [ -x "$FW" ] && "$FW" --getblockall 2>/dev/null | grep -qi 'block all enabled'; then
  warn 'De firewall van deze Mac blokkeert ALLE inkomende verbindingen. Zet in Instellingen > Netwerk > Firewall > Opties "Alle inkomende verbindingen blokkeren" UIT, anders blijft de Mac onbereikbaar.'
else
  good 'De firewall blokkeert Externe login niet.'
fi

# ---------------------------------------------------------
step 5 'Slaapstand uitzetten (ook met dichtgeklapt deksel)'
if [ -z "$(get_state SLEEP_BATTERY)" ] && [ -z "$(get_state SLEEP_AC)" ]; then
  set_state SLEEP_BATTERY "$(get_sleep 'Battery Power')"
  set_state SLEEP_AC "$(get_sleep 'AC Power')"
  set_state DISABLESLEEP "$(pmset -g 2>/dev/null | awk '/SleepDisabled/ { print $2; exit }')"
fi
sudo pmset -a sleep 0 >/dev/null 2>&1
sudo pmset -a disablesleep 1 >/dev/null 2>&1
good 'Deze Mac gaat niet meer slapen. Laat een MacBook aan de lader staan.'

# ---------------------------------------------------------
step 6 'Controleren of de SSH-server echt antwoordt'
sleep 1
BANNER="$( ( exec 3<>/dev/tcp/127.0.0.1/22 && read -r -t 3 line <&3 && echo "$line" ) 2>/dev/null | tr -d '\r' )"
case "$BANNER" in
  SSH-*) good "De SSH-server antwoordt: $BANNER" ;;
  *) fail 'Poort 22 is open, maar er antwoordt geen SSH-server. Herstart de Mac en draai dit bestand opnieuw.' ;;
esac

# ---------------------------------------------------------
step 7 'Toegang tot Bureaublad, Documenten en Downloads op afstand'
info 'Dit controleer ik door op deze Mac zelf in te loggen via SSH (met een wegwerpsleutel).'
check_remote_access
if [ "$TCC_RESULT" = 'TCC_OK' ]; then
  good 'Op afstand heb je toegang tot Bureaublad, Documenten en Downloads.'
elif [ "$TCC_RESULT" = 'TCC_NO' ]; then
  info 'macOS blokkeert die mappen standaard voor verbindingen van buiten ("Operation not permitted").'
  info 'Dat moet je 1 keer zelf toestaan; macOS laat een script dat niet toe. Ik help je en controleer het daarna.'
  tries=0
  while [ "$TCC_RESULT" = 'TCC_NO' ] && [ "$tries" -lt 3 ]; do
    tries=$((tries + 1))
    echo
    if [ "$tries" -eq 1 ]; then
      info 'Het venster Instellingen opent nu (Algemeen > Delen). Doe dit:'
      info '  1. Klik bij "Externe login" op de i-knop.'
      info '  2. Zet "Volledige schijftoegang voor externe gebruikers toestaan" AAN.'
      open 'x-apple.systempreferences:com.apple.Sharing-Settings.extension' >/dev/null 2>&1 \
        || open 'x-apple.systempreferences:com.apple.preferences.sharing' >/dev/null 2>&1
    else
      info 'Nog niet gelukt, of staat die schakelaar er niet? Probeer dan dit:'
      info '  1. Het venster Volledige schijftoegang opent nu, en Finder toont het bestand sshd-keygen-wrapper.'
      info '  2. Sleep dat bestand in de lijst (of klik op +) en zet de schakelaar ernaast AAN.'
      open 'x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles' >/dev/null 2>&1
      open -R /usr/libexec/sshd-keygen-wrapper >/dev/null 2>&1
    fi
    read -r -p '      Druk op Enter om opnieuw te controleren (of typ s + Enter om over te slaan): ' ANSWER
    case "$ANSWER" in s|S) break ;; esac
    info 'Opnieuw controleren...'
    check_remote_access
  done
  if [ "$TCC_RESULT" = 'TCC_OK' ]; then
    good 'Gelukt: op afstand heb je nu toegang tot Bureaublad, Documenten en Downloads.'
  else
    warn "Op afstand zie je Bureaublad, Documenten en Downloads nog niet ('Operation not permitted'). Zet in Instellingen > Algemeen > Delen > Externe login (i-knop) 'Volledige schijftoegang voor externe gebruikers' aan en draai dit bestand opnieuw om het te controleren."
  fi
else
  warn "Kon niet automatisch controleren of Bureaublad, Documenten en Downloads bereikbaar zijn. Zie je op afstand 'Operation not permitted'? Zet dan in Instellingen > Algemeen > Delen > Externe login (i-knop) 'Volledige schijftoegang voor externe gebruikers' aan."
fi

# ---------------------------------------------------------
step 8 'Gegevens voor PC-1 verzamelen'
IFACE="$(route -n get default 2>/dev/null | awk '/interface:/ { print $2; exit }')"
IP=''
[ -n "$IFACE" ] && IP="$(ipconfig getifaddr "$IFACE" 2>/dev/null)"
if [ -z "$IP" ]; then
  for i in en0 en1 en2 en3 en4; do
    IP="$(ipconfig getifaddr "$i" 2>/dev/null)"
    [ -n "$IP" ] && break
  done
fi
[ -z "$IP" ] && IP='(niet gevonden, kijk in Instellingen > Netwerk)'
LOCALNAME="$(scutil --get LocalHostName 2>/dev/null)"

info "IP-adres: $IP"
info "Gebruikersnaam: $ME"
[ -n "$LOCALNAME" ] && info "Netwerknaam: $LOCALNAME.local"

MSG="De Mac is klaar. De SSH-server draait op de achtergrond.

Vul dit in bij pc1-remote-mac.bat op PC-1:

  IP-adres:  $IP
  Gebruikersnaam:  $ME

Verder hoef je niets in te vullen. Er wordt geen wachtwoord gevraagd.

Deze Mac gaat niet meer slapen. Laat een MacBook aan de lader staan."
if [ "${#WARNINGS[@]}" -gt 0 ]; then
  MSG="$MSG

LET OP:"
  for w in "${WARNINGS[@]}"; do MSG="$MSG
- $w"; done
fi

printf '\n%sKLAAR.%s Je mag dit venster sluiten.\n' "$C_GREEN" "$C_OFF"
popup "$MSG" "note"
exit 0
