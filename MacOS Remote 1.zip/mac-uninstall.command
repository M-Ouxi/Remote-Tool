#!/bin/bash
# ============================================================
#  mac-uninstall.command  -  draai dit op de Mac (PC-2)
#
#  Start het zo: open Terminal, typ  bash  (met een spatie erachter),
#  sleep dit bestand in het venster en druk op Enter.
#
#  Draait terug wat mac-server.command deed: de sleutel van PC-1 wordt
#  ingetrokken, de slaapstand-instellingen komen terug, en Externe login
#  gaat alleen uit als dit script hem zelf had aangezet.
# ============================================================

PUBKEY='ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDXz1jjOXN/lr3rtyEw02VnIhW8wpd8uZhVUAq0o9byV remote-shared'

ME="$(id -un)"
BASE="$HOME/Library/Application Support/RemoteSetup"
STATE="$BASE/state.env"

C_CYAN=$'\033[36m'; C_GREEN=$'\033[32m'; C_RED=$'\033[31m'; C_OFF=$'\033[0m'
say()  { printf '  %s\n' "$1"; }

popup() {
  osascript - "$1" >/dev/null 2>&1 <<'APPLESCRIPT'
on run argv
  display dialog (item 1 of argv) with title "Uninstall" buttons {"OK"} default button 1 with icon note
end run
APPLESCRIPT
}

get_state() { [ -f "$STATE" ] && grep "^$1=" "$STATE" | head -n 1 | cut -d= -f2-; }

clear
printf '%sMac terugzetten...%s\n\n' "$C_CYAN" "$C_OFF"

if [ "$(id -u)" -eq 0 ]; then
  printf '%sDraai dit bestand NIET met sudo. Start het gewoon als jezelf.%s\n' "$C_RED" "$C_OFF"
  exit 1
fi

say 'macOS vraagt zo om het wachtwoord van deze Mac (je ziet niets verschijnen).'
if ! sudo -v; then
  printf '%sHet wachtwoord werd niet geaccepteerd. Draai dit bestand opnieuw.%s\n' "$C_RED" "$C_OFF"
  exit 1
fi

say 'Sleutel van PC-1 intrekken...'
AK="$HOME/.ssh/authorized_keys"
if [ -f "$AK" ]; then
  grep -vxF "$PUBKEY" "$AK" > "$AK.tmp" 2>/dev/null
  if [ -s "$AK.tmp" ]; then
    mv "$AK.tmp" "$AK"; chmod 600 "$AK"
  else
    rm -f "$AK.tmp" "$AK"
  fi
fi

say 'Slaapstand-instellingen terugzetten...'
B="$(get_state SLEEP_BATTERY)"; C="$(get_state SLEEP_AC)"; D="$(get_state DISABLESLEEP)"
[ -n "$B" ] && sudo pmset -b sleep "$B" >/dev/null 2>&1
[ -n "$C" ] && sudo pmset -c sleep "$C" >/dev/null 2>&1
if [ -n "$D" ]; then
  sudo pmset -a disablesleep "$D" >/dev/null 2>&1
else
  sudo pmset -a disablesleep 0 >/dev/null 2>&1
fi

if [ "$(get_state GROUP_ADDED)" = "1" ]; then
  say 'Account weer uit de lijst met toegestane gebruikers halen...'
  sudo dseditgroup -o edit -d "$ME" -t user com.apple.access_ssh >/dev/null 2>&1
fi

if [ "$(get_state REMOTELOGIN_BY_SCRIPT)" = "1" ]; then
  say 'Externe login weer uitzetten (die stond uit voordat mac-server.command draaide)...'
  sudo systemsetup -setremotelogin off >/dev/null 2>&1 \
    || sudo launchctl unload -w /System/Library/LaunchDaemons/ssh.plist >/dev/null 2>&1
  REMOTE_NOTE='Externe login is weer uitgezet.'
else
  REMOTE_NOTE='Externe login is niet aangeraakt: die stond al aan voordat mac-server.command draaide. Wil je hem uit, zet hem dan zelf uit in Instellingen > Algemeen > Delen.'
fi

say 'Restanten opruimen...'
rm -rf "$BASE"

printf '\n%sKlaar.%s\n' "$C_GREEN" "$C_OFF"
popup "De sleutel van PC-1 is ingetrokken en de slaapstand-instellingen zijn teruggezet.

$REMOTE_NOTE"
exit 0
