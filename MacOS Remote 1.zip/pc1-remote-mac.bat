@echo off
setlocal
title PC-1: RemoteMac instellen
REM ============================================================
REM  pc1-remote-mac.bat  -  draai dit op PC-1 (Windows) om een MAC te bedienen
REM  Hoort bij mac-server.command (op de Mac). Bevat de geheime sleutel:
REM  zet dit bestand dus niet op een plek waar anderen erbij kunnen.
REM  Vraagt eenmalig het IP-adres en de gebruikersnaam van de Mac.
REM  Daarna typ je alleen nog "RemoteMac" en zit je erin, zonder wachtwoord.
REM  Veilig om opnieuw te draaien (bijv. als het IP-adres verandert).
REM ============================================================

set "SELF=%~f0"
set "PS1=%TEMP%\remote-pc1-mac-setup.ps1"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:SELF); $i=$s.LastIndexOf('#PS-START',[StringComparison]::Ordinal); [IO.File]::WriteAllText($env:PS1,$s.Substring($i))"
if not exist "%PS1%" goto noextract
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%errorlevel%"
del "%PS1%" >nul 2>&1
if not "%RC%"=="0" pause
exit /b %RC%

:noextract
echo.
echo Kon het script niet uitpakken in de map %TEMP%.
echo.
pause
exit /b 1

#PS-START
# Bewust 'Continue' en niet 'Stop': ssh.exe schrijft normale, onschuldige tekst
# naar stderr (bijv. "Warning: Permanently added ... to the list of known hosts.").
# Met 'Stop' zou PowerShell dat als fatale fout behandelen.
$ErrorActionPreference = 'Continue'
$Host.UI.RawUI.WindowTitle = 'PC-1: RemoteMac instellen'

# Geheime helft van de sleutel. De publieke helft staat in mac-server.command
# en wordt daar automatisch toegelaten.
$PRIVKEY = @'
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtz
c2gtZWQyNTUxOQAAACA189Y4zlzf5a967chMNNlZyIVvMKXfLmYVVAKtKPW8lQAA
AIifrIWUn6yFlAAAAAtzc2gtZWQyNTUxOQAAACA189Y4zlzf5a967chMNNlZyIVv
MKXfLmYVVAKtKPW8lQAAAECp2/RW7oAF7HamRH3dLfgITsBq5emCCtg4KCaAGorI
nDXz1jjOXN/lr3rtyEw02VnIhW8wpd8uZhVUAq0o9byVAAAAAAECAwQF
-----END OPENSSH PRIVATE KEY-----
'@
$EXPECTED = 'AAAAC3NzaC1lZDI1NTE5AAAAIDXz1jjOXN/lr3rtyEw02VnIhW8wpd8uZhVUAq0o9byV'

function Test-Ping($ip) {
    try { return [bool](Test-Connection -ComputerName $ip -Count 2 -Quiet) } catch { return $false }
}

function Test-Ssh($ip, $ms) {
    $r = [pscustomobject]@{ State = 'timeout'; Banner = '' }
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $a = $c.BeginConnect($ip, 22, $null, $null)
        if (-not $a.AsyncWaitHandle.WaitOne($ms)) { return $r }
        try { $c.EndConnect($a) } catch { $r.State = 'refused'; return $r }
        $r.State = 'open'
        $s = $c.GetStream()
        $s.ReadTimeout = 3000
        $buf = New-Object byte[] 255
        $n = $s.Read($buf, 0, 255)
        if ($n -gt 0) { $r.Banner = [Text.Encoding]::ASCII.GetString($buf, 0, $n).Trim() }
    }
    catch { }
    finally { $c.Close() }
    return $r
}

Clear-Host
Write-Host '==========================================' -ForegroundColor Cyan
Write-Host '  PC-1: RemoteMac instellen (Mac als PC-2)' -ForegroundColor Cyan
Write-Host '==========================================' -ForegroundColor Cyan
Write-Host ''

if (-not (Get-Command ssh.exe -ErrorAction SilentlyContinue)) {
    Write-Host 'De SSH-client is niet gevonden op deze pc.' -ForegroundColor Red
    Write-Host 'Installeer hem via Instellingen > Apps > Optionele onderdelen > OpenSSH-client.'
    exit 1
}

# ---- Sleutel op schijf zetten (alleen leesbaar voor jezelf) ----
$tools = Join-Path $env:USERPROFILE 'RemoteTools'
New-Item -ItemType Directory -Force -Path $tools | Out-Null
$keyPath = Join-Path $tools 'mac.key'
$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value

if (Test-Path -LiteralPath $keyPath) {
    & icacls.exe $keyPath /grant:r ('*' + $sid + ':F') | Out-Null
    Remove-Item -LiteralPath $keyPath -Force -ErrorAction SilentlyContinue
}
# LET OP: een sleutelbestand moet LF-regeleinden hebben en eindigen met een nieuwe regel,
# anders weigert ssh het ("invalid format") en vraagt hij toch om een wachtwoord.
$keyText = (($PRIVKEY -replace "`r", '').Trim()) + "`n"
[System.IO.File]::WriteAllText($keyPath, $keyText, (New-Object System.Text.UTF8Encoding($false)))
& icacls.exe $keyPath /inheritance:r /grant:r ('*' + $sid + ':R') | Out-Null

# Controleren dat ssh de sleutel echt kan lezen
if (Get-Command ssh-keygen.exe -ErrorAction SilentlyContinue) {
    $derived = [string](& ssh-keygen.exe -y -f $keyPath 2>$null)
    if (-not $derived.Contains($EXPECTED)) {
        Write-Host 'De sleutel op deze pc is ongeldig of onleesbaar. Draai dit bestand opnieuw.' -ForegroundColor Red
        Write-Host '(Blijft dit gebeuren: controleer of een antivirusprogramma het bestand in de map RemoteTools aanpast.)' -ForegroundColor Red
        exit 1
    }
}

$kh = Join-Path $tools 'known_hosts_mac'
if (Test-Path $kh) { Remove-Item $kh -Force }

# ---- Eigen netwerk tonen ----
$mine = @(Get-NetIPConfiguration -ErrorAction SilentlyContinue |
    Where-Object { $_.IPv4DefaultGateway -and $_.IPv4Address } |
    ForEach-Object { $_.IPv4Address.IPAddress })
$localIps = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object { $_.IPAddress })
if ($mine.Count -gt 0) {
    Write-Host ('Het IP-adres van deze pc (PC-1): ' + ($mine -join ', '))
    Write-Host 'Het IP-adres van de Mac moet met (bijna) dezelfde cijfers beginnen, bijvoorbeeld beide 192.168.1.x.'
    Write-Host ''
}
Write-Host 'Typ het IP-adres uit de melding die mac-server.command op de Mac liet zien.'
Write-Host 'Dit vraag ik maar deze ene keer; daarna typ je alleen nog RemoteMac.'
Write-Host ''

# ---- Adres van de Mac vragen ----
do {
    $pc = (Read-Host 'IP-adres of netwerknaam van de Mac (bijv. 192.168.1.20 of naam.local)').Trim()
    $candidates = @()
    if (-not $pc) {
        Write-Host 'Vul een adres in.' -ForegroundColor Yellow
        continue
    }
    $parsed = $null
    if ([System.Net.IPAddress]::TryParse($pc, [ref]$parsed) -and ($parsed.AddressFamily -eq 'InterNetwork')) {
        $candidates = @($pc)
    }
    else {
        try {
            $candidates = @([System.Net.Dns]::GetHostAddresses($pc) |
                Where-Object { $_.AddressFamily -eq 'InterNetwork' } |
                ForEach-Object { $_.ToString() })
        }
        catch { }
        if ($candidates.Count -eq 0) {
            Write-Host ("De naam '" + $pc + "' kan niet worden gevonden. Gebruik het IP-adres van de Mac.") -ForegroundColor Yellow
        }
    }

    # Adressen van DEZE pc zelf eruit halen (bijv. een virtueel VirtualBox-adres zoals 192.168.56.1)
    if ($candidates.Count -gt 0) {
        $others = @($candidates | Where-Object { $localIps -notcontains $_ })
        if ($others.Count -eq 0) {
            Write-Host ('Dat adres (' + ($candidates -join ', ') + ') is van DEZE pc zelf (PC-1), niet van de Mac.') -ForegroundColor Yellow
            Write-Host 'Typ het IP-adres dat mac-server.command op de Mac liet zien.' -ForegroundColor Yellow
        }
        $candidates = $others
    }
    Write-Host ''
} while ($candidates.Count -eq 0)

# Adressen op hetzelfde netwerk als deze pc eerst proberen
$prefixes = @($mine | ForEach-Object { (($_ -split '\.')[0..2]) -join '.' })
$candidates = @($candidates | Sort-Object { if ($prefixes -contains ((($_ -split '\.')[0..2]) -join '.')) { 0 } else { 1 } })

# ---- Verbinding testen ----
Write-Host 'Verbinding testen...' -ForegroundColor Cyan
$chosen = $null
$firstPing = $false
$firstState = 'timeout'
$idx = 0
foreach ($ip in $candidates) {
    Write-Host ('  ' + $ip)
    $ping = Test-Ping $ip
    $ssh = Test-Ssh $ip 5000
    if ($ping) { Write-Host '    ping:      antwoord ontvangen' -ForegroundColor Green }
    else { Write-Host '    ping:      geen antwoord (bij een Mac is dat niet erg)' -ForegroundColor Yellow }
    if (($ssh.State -eq 'open') -and ($ssh.Banner -like 'SSH-*')) {
        Write-Host ('    poort 22:  open, SSH-server antwoordt (' + $ssh.Banner + ')') -ForegroundColor Green
        $chosen = $ip
        break
    }
    elseif ($ssh.State -eq 'open') { Write-Host '    poort 22:  open, maar er antwoordt geen SSH-server' -ForegroundColor Yellow }
    elseif ($ssh.State -eq 'refused') { Write-Host '    poort 22:  geweigerd (de Mac is bereikbaar, maar Externe login staat uit)' -ForegroundColor Yellow }
    else { Write-Host '    poort 22:  geen antwoord (time-out)' -ForegroundColor Yellow }
    if ($idx -eq 0) { $firstPing = $ping; $firstState = $ssh.State }
    $idx++
}

if ($chosen) {
    $target = $chosen
    Write-Host ''
    Write-Host 'De Mac is bereikbaar en de SSH-server werkt.' -ForegroundColor Green
    if ($prefixes.Count -gt 0 -and ($prefixes -notcontains ((($target -split '\.')[0..2]) -join '.'))) {
        Write-Host 'Let op: dit adres begint anders dan dat van deze pc. Dat is zeldzaam; klopt het IP-adres echt?' -ForegroundColor Yellow
    }
}
else {
    $target = $candidates[0]
    Write-Host ''
    Write-Host 'De Mac is NIET bereikbaar via SSH. Waarschijnlijke oorzaak:' -ForegroundColor Red
    if ($firstState -eq 'refused') {
        Write-Host '  Externe login staat uit. Draai mac-server.command op de Mac, of zet het aan in Instellingen > Algemeen > Delen.'
    }
    elseif ($firstPing) {
        Write-Host '  De Mac is wel bereikbaar (ping werkt), maar poort 22 wordt geblokkeerd.'
        Write-Host '  Draai mac-server.command opnieuw op de Mac en lees de LET OP-regels in de melding.'
    }
    else {
        Write-Host '  De Mac reageert helemaal niet. Controleer:'
        Write-Host '   - Staat de Mac aan en niet in slaapstand?'
        Write-Host '   - Klopt het IP-adres? Staat in de melding van mac-server.command.'
        Write-Host '   - Zitten beide pc''s op hetzelfde netwerk (geen gastnetwerk, geen VPN aan)?'
        Write-Host '   - Heb je mac-server.command op de Mac gedraaid en de melding "De Mac is klaar" gezien?'
    }
    Write-Host ''
    $a = Read-Host 'Het RemoteMac-commando toch aanmaken? (j/n) [j]'
    if ($a -match '^[nN]') { exit 1 }
}

do {
    $user2 = (Read-Host 'Gebruikersnaam op de Mac (staat in de melding van mac-server.command)').Trim()
    if (-not $user2) { Write-Host 'Vul een gebruikersnaam in.' -ForegroundColor Yellow }
} while (-not $user2)

# ---- RemoteMac.cmd aanmaken: IP en gebruiker liggen al vast, geen vragen meer ----
$cmdLines = New-Object System.Collections.Generic.List[string]
$cmdLines.Add('@echo off')
$cmdLines.Add('setlocal EnableExtensions')
$cmdLines.Add('set "RT=%~dp0"')
$cmdLines.Add(('set "HOST=' + $target + '"'))
$cmdLines.Add(('set "RUSER=' + $user2 + '"'))
$cmdLines.Add('set "H=%~1"')
$cmdLines.Add('if defined H set "HOST=%H%"')
$cmdLines.Add('set "REST="')
$cmdLines.Add('if defined H shift')
$cmdLines.Add(':nextarg')
$cmdLines.Add('if "%~1"=="" goto run')
$cmdLines.Add('set REST=%REST% %1')
$cmdLines.Add('shift')
$cmdLines.Add('goto nextarg')
$cmdLines.Add(':run')
$cmdLines.Add('ssh -4 -o ConnectTimeout=8 -o ServerAliveInterval=30 -o StrictHostKeyChecking=accept-new -o "UserKnownHostsFile=%RT%known_hosts_mac" -o IdentitiesOnly=yes -i "%RT%mac.key" -l %RUSER% %HOST% %REST%')
$cmdLines.Add('exit /b %errorlevel%')
Set-Content -Path (Join-Path $tools 'RemoteMac.cmd') -Value $cmdLines -Encoding ascii

# ---- Map aan gebruikers-PATH toevoegen ----
$p = [Environment]::GetEnvironmentVariable('Path', 'User')
if (-not $p) { $p = '' }
if (($p -split ';') -notcontains $tools) {
    [Environment]::SetEnvironmentVariable('Path', ($p.TrimEnd(';') + ';' + $tools).TrimStart(';'), 'User')
}

Write-Host ''
Write-Host 'Het commando "RemoteMac" is aangemaakt.' -ForegroundColor Green

# ---- Controleren of inloggen zonder wachtwoord werkt ----
$keyOk = $false
if ($chosen) {
    Write-Host ''
    Write-Host 'Controleren of inloggen zonder wachtwoord werkt...' -ForegroundColor Cyan
    $common = @('-4', '-o', 'ConnectTimeout=8', '-o', 'StrictHostKeyChecking=accept-new', '-o', ('UserKnownHostsFile=' + $kh), '-o', 'IdentitiesOnly=yes', '-i', $keyPath, '-l', $user2)
    $out = & ssh.exe @common -o BatchMode=yes $target exit 2>&1 | ForEach-Object { $_.ToString() }
    $code = $LASTEXITCODE
    if ($code -eq 0) {
        $keyOk = $true
        Write-Host 'Het werkt: je komt binnen zonder wachtwoord.' -ForegroundColor Green
    }
    else {
        $text = (($out | Where-Object { $_ -and ($_ -notlike 'Warning: Permanently added*') }) -join "`n")
        Write-Host 'Inloggen zonder wachtwoord lukt nog niet.' -ForegroundColor Red
        if ($text) { Write-Host ('Melding van ssh: ' + $text) -ForegroundColor Red }
        Write-Host ''
        Write-Host 'Controleer dit:' -ForegroundColor Yellow
        Write-Host ('  - Is "' + $user2 + '" echt de gebruikersnaam van de Mac? Gebruik de naam uit de melding van mac-server.command')
        Write-Host '    (de korte accountnaam, geen volledige naam met spaties of hoofdletters).'
        Write-Host '  - Heb je mac-server.command op de Mac gedraaid en de melding "De Mac is klaar" gezien?'
        Write-Host '    Draai hem anders opnieuw: die laat de sleutel toe.'
        Write-Host '  - "Operation not permitted" of "Permission denied (publickey)": draai mac-server.command opnieuw op de Mac.'
        Write-Host '  - Daarna dit bestand (pc1-remote-mac.bat) gewoon opnieuw draaien.'
    }
}

if ($keyOk) {
    Write-Host ''
    $go = Read-Host 'Nu meteen verbinden met de Mac om te testen? (j/n) [j]'
    if (-not $go) { $go = 'j' }
    if ($go -match '^[jJyY]') {
        Write-Host ''
        Write-Host 'Verbinden... Typ "exit" om terug te gaan naar PC-1.' -ForegroundColor Cyan
        Write-Host ''
        & (Join-Path $tools 'RemoteMac.cmd')
        Write-Host ''
    }
}

Write-Host '==========================================' -ForegroundColor Green
Write-Host '  Gebruik' -ForegroundColor Green
Write-Host '==========================================' -ForegroundColor Green
Write-Host '  Open een NIEUWE terminal en typ:'
Write-Host ''
Write-Host '      RemoteMac' -ForegroundColor Cyan
Write-Host ''
Write-Host '  Je zit dan meteen op de Mac, zonder iets in te vullen. Gebruik cd, ls en pwd.'
Write-Host '  Typ "exit" om terug te gaan naar PC-1.'
Write-Host ''
Write-Host '  Los commando zonder sessie, bijvoorbeeld:'
Write-Host '      RemoteMac ls ~/Documents' -ForegroundColor Cyan
Write-Host ''
Write-Host '  Verandert het IP-adres van de Mac? Draai dit bestand dan opnieuw.'
if (-not $keyOk) {
    Write-Host ''
    Write-Host '  Let op: inloggen zonder wachtwoord is nog niet bevestigd (zie hierboven).' -ForegroundColor Yellow
}
Write-Host ''
[void](Read-Host 'Druk op Enter om te sluiten')
exit 0
