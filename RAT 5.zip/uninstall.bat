@echo off
setlocal
title Uninstall
REM ============================================================
REM  uninstall.bat  -  werkt op PC-1 en PC-2
REM  Draait alles terug wat pc1-remote.bat en pc2-server.bat deden:
REM  de ingebouwde sleutel, het Remote-commando, de SSH-server en de
REM  slaapstand-instellingen. Vraagt alleen om administrator-rechten
REM  als er op deze pc een SSH-server staat.
REM ============================================================

set "SELF=%~f0"
set "PS1=%TEMP%\remote-uninstall.ps1"
set "MODE=user"
if /i "%~1"=="elevated" set "MODE=server"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:SELF); $i=$s.LastIndexOf('#PS-START',[StringComparison]::Ordinal); [IO.File]::WriteAllText($env:PS1,$s.Substring($i))"
if not exist "%PS1%" goto noextract
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Mode %MODE%
set "RC=%errorlevel%"
del "%PS1%" >nul 2>&1
if not "%RC%"=="0" pause
exit /b %RC%

:noextract
echo.
echo Kon het script niet uitpakken in de map %TEMP%.
echo.
pause
exit /b 1

#PS-START
param([string]$Mode = 'user')
$ErrorActionPreference = 'SilentlyContinue'
$Host.UI.RawUI.WindowTitle = 'Uninstall'

$PUBKEY = 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDXz1jjOXN/lr3rtyEw02VnIhW8wpd8uZhVUAq0o9byV remote-shared'

Add-Type -AssemblyName System.Windows.Forms
function Show-Box($text) {
    $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true }
    [void][System.Windows.Forms.MessageBox]::Show($owner, $text, 'Uninstall', 'OK', 'Information')
}
function Remove-KeyLine($file) {
    if (Test-Path -LiteralPath $file) {
        $keep = @(Get-Content -LiteralPath $file | Where-Object { $_.Trim() -and ($_.Trim() -ne $PUBKEY) })
        if ($keep.Count -eq 0) { Remove-Item -LiteralPath $file -Force }
        else { Set-Content -LiteralPath $file -Value $keep -Encoding ascii }
    }
}

$base = Join-Path $env:ProgramData 'RemoteSetup'

# ================= Deel 1: je eigen gebruikersmap (PC-1 en PC-2) =================
if ($Mode -eq 'user') {
    Write-Host 'Remote-commando en sleutel verwijderen...'

    $tools = Join-Path $env:USERPROFILE 'RemoteTools'
    if (Test-Path $tools) { Remove-Item $tools -Recurse -Force }

    $p = [Environment]::GetEnvironmentVariable('Path', 'User')
    if ($p) {
        $n = (($p -split ';') | Where-Object { $_ -and ($_ -ne $tools) }) -join ';'
        [Environment]::SetEnvironmentVariable('Path', $n, 'User')
    }

    # Als deze pc ooit als PC-2 is ingesteld: de sleutel uit de eigen authorized_keys halen
    Remove-KeyLine (Join-Path $env:USERPROFILE '.ssh\authorized_keys')

    # Restanten van oudere versies van deze scripts
    Remove-Item (Join-Path $env:USERPROFILE '.ssh\id_remote_pc2') -Force
    Remove-Item (Join-Path $env:USERPROFILE '.ssh\id_remote_pc2.pub') -Force
    Get-LocalUser -Name 'remote' -ErrorAction SilentlyContinue | Remove-LocalUser

    $serverPresent = [bool](Get-Service -Name sshd) -or (Test-Path $base)
    if (-not $serverPresent) {
        Show-Box 'Het Remote-commando en de sleutel zijn verwijderd.'
        exit 0
    }

    Write-Host 'Er staat een SSH-server op deze pc. Er wordt om administrator-rechten gevraagd om die te verwijderen...'
    Start-Process -FilePath $env:SELF -ArgumentList 'elevated' -Verb RunAs
    exit 0
}

# ================= Deel 2: SSH-server verwijderen (PC-2, administrator) =================
$Host.UI.RawUI.WindowTitle = 'Uninstall: SSH-server verwijderen'
Write-Host 'SSH-server en instellingen verwijderen. Dit kan een minuut duren...'

Write-Host '  Sleutel van PC-1 intrekken...'
Remove-KeyLine (Join-Path $env:ProgramData 'ssh\administrators_authorized_keys')
Remove-KeyLine (Join-Path $env:USERPROFILE '.ssh\authorized_keys')

Write-Host '  Restant-account "remote" verwijderen (van een oudere versie van dit script)...'
Get-LocalUser -Name 'remote' -ErrorAction SilentlyContinue | Remove-LocalUser
Get-CimInstance Win32_UserProfile | Where-Object { $_.LocalPath -like '*\remote' } | Remove-CimInstance

Write-Host '  Service stoppen...'
Stop-Service -Name sshd -Force
Set-Service -Name sshd -StartupType Disabled

Write-Host '  Firewallregels verwijderen...'
foreach ($n in 'Remote-SSH-22', 'Remote-SSH-ping', 'OpenSSH-Server-In-TCP') {
    Get-NetFirewallRule -Name $n | Remove-NetFirewallRule
}

Write-Host '  Slaapstand-instellingen terugzetten...'
$pj = Join-Path $base 'power-backup.json'
if (Test-Path $pj) {
    foreach ($b in @(Get-Content $pj -Raw | ConvertFrom-Json)) {
        & powercfg /setacvalueindex SCHEME_CURRENT $b.sub $b.set $b.ac | Out-Null
        & powercfg /setdcvalueindex SCHEME_CURRENT $b.sub $b.set $b.dc | Out-Null
    }
    & powercfg /setactive SCHEME_CURRENT | Out-Null
}

Write-Host '  Instellingen uit het register verwijderen...'
Remove-Item 'HKLM:\SOFTWARE\OpenSSH' -Recurse -Force

Write-Host '  SSH-server verwijderen...'
$method = ''
$mf = Join-Path $base 'method.txt'
if (Test-Path $mf) { $method = (Get-Content $mf -Raw).Trim() }
if ($method -eq 'msi') {
    $msi = Join-Path $base 'openssh.msi'
    if (Test-Path $msi) {
        Start-Process -FilePath 'msiexec.exe' -ArgumentList @('/x', ('"' + $msi + '"'), '/qn', '/norestart') -Wait
    }
}
else {
    Remove-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0' | Out-Null
}

Write-Host '  Restanten opruimen...'
Remove-Item (Join-Path $env:ProgramData 'ssh') -Recurse -Force
Remove-Item $base -Recurse -Force

Show-Box "De SSH-server, de sleutel en alle instellingen zijn verwijderd.`n`nDe slaapstand-instellingen zijn teruggezet.`nHerstart PC-2 om het verwijderen helemaal af te ronden."
exit 0
