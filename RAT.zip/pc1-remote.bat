@echo off
setlocal EnableExtensions
title PC-1: Remote commando maken

REM ============================================================
REM  pc1-remote.bat  -  draai dit op PC-1 (de pc waarmee je bestuurt)
REM  Maakt het commando "Remote" dat verbindt met PC-2.
REM ============================================================

where ssh >nul 2>&1
if %errorlevel% neq 0 (
    echo De SSH-client is niet gevonden op deze pc.
    echo Installeer hem via: Instellingen ^> Apps ^> Optionele onderdelen ^> OpenSSH-client
    echo.
    pause
    exit /b
)

:vraag
echo.
set "DOELPC="
set "DOELUSER="
set /p DOELPC=IP-adres of computernaam van PC-2 (bijv. 192.168.1.50): 
set /p DOELUSER=Gebruikersnaam op PC-2: 

if "%DOELPC%"=="" goto fout
if "%DOELUSER%"=="" goto fout

set "BINDIR=%USERPROFILE%\RemoteTools"
if not exist "%BINDIR%" mkdir "%BINDIR%"

> "%BINDIR%\Remote.cmd" echo @echo off
>> "%BINDIR%\Remote.cmd" echo ssh %DOELUSER%@%DOELPC% %%*

REM Map toevoegen aan de gebruikers-PATH (zonder setx, dat kapt lange PATH's af)
powershell -NoProfile -Command "$d='%BINDIR%'; $p=[Environment]::GetEnvironmentVariable('Path','User'); if (-not $p) { $p='' }; if (($p -split ';') -notcontains $d) { [Environment]::SetEnvironmentVariable('Path', ($p.TrimEnd(';') + ';' + $d).TrimStart(';'), 'User') }"

echo.
echo ==========================================
echo   Klaar!
echo ==========================================
echo   Open een NIEUWE terminal (cmd of PowerShell) en typ:
echo.
echo       Remote
echo.
echo   Je zit dan in PC-2 en kunt cd / dir / ls gebruiken.
echo   Typ "exit" om terug te gaan naar PC-1.
echo.
echo   Los commando zonder sessie kan ook, bijvoorbeeld:
echo       Remote dir C:\Users
echo.
echo   De eerste keer vraagt SSH om "yes" te typen en daarna
echo   het Windows-wachtwoord van PC-2.
echo.
pause
exit /b

:fout
echo.
echo Je moet beide velden invullen. Probeer het opnieuw.
goto vraag
