@echo off
REM ============================================================
REM  uninstall.bat  -  werkt op PC-1 en PC-2
REM  Verwijdert alles wat pc1-remote.bat en pc2-server.bat hebben
REM  toegevoegd. Dubbelklik; vraagt alleen om admin als er op deze
REM  pc een SSH-server staat. Geen venster, sluit meteen.
REM ============================================================

REM Opnieuw gestart als admin? Dan direct naar het server-deel
if /i "%~1"=="admin" goto server

REM ---- Deel 1 (PC-1): Remote-commando opruimen, als huidige gebruiker ----
if exist "%USERPROFILE%\RemoteTools" rmdir /s /q "%USERPROFILE%\RemoteTools"

powershell -NoProfile -WindowStyle Hidden -Command "$d='%USERPROFILE%\RemoteTools'; $p=[Environment]::GetEnvironmentVariable('Path','User'); if ($p) { $n=(($p -split ';') | Where-Object { $_ -and $_ -ne $d }) -join ';'; [Environment]::SetEnvironmentVariable('Path',$n,'User') }"

REM ---- Staat er een SSH-server op deze pc? Zo niet: klaar, geen admin nodig ----
sc query sshd >nul 2>&1
if %errorlevel% neq 0 exit /b

REM ---- Wel een server: admin nodig ----
net session >nul 2>&1
if %errorlevel% equ 0 goto server

powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList 'admin' -Verb RunAs -WindowStyle Hidden"
exit /b

REM ---- Deel 2 (PC-2): SSH-server verwijderen ----
:server
powershell -NoProfile -WindowStyle Hidden -Command "$ErrorActionPreference='SilentlyContinue'; Stop-Service sshd -Force; Set-Service sshd -StartupType Disabled; Remove-NetFirewallRule -Name 'OpenSSH-Server-In-TCP'; Remove-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0 | Out-Null"

REM Restanten van de server (sleutels, config, logs)
if exist "%ProgramData%\ssh" rmdir /s /q "%ProgramData%\ssh"

exit /b