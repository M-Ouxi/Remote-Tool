@echo off
REM ============================================================
REM  pc2-server.bat  -  draai dit op PC-2 (de pc die bestuurd wordt)
REM  Dubbelklik, bevestig de admin-vraag, klaar. Geen venster.
REM ============================================================

REM Geen admin? Opnieuw starten als admin (verborgen) en dit venster sluiten
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs -WindowStyle Hidden"
    exit /b
)

REM Wel admin: SSH-server installeren, automatisch laten starten, firewall openen
powershell -NoProfile -WindowStyle Hidden -Command "$ErrorActionPreference='SilentlyContinue'; if ((Get-WindowsCapability -Online -Name 'OpenSSH.Server*').State -ne 'Installed') { Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0 | Out-Null }; Set-Service -Name sshd -StartupType Automatic; Start-Service sshd; if (-not (Get-NetFirewallRule -Name 'OpenSSH-Server-In-TCP' -ErrorAction SilentlyContinue)) { New-NetFirewallRule -Name 'OpenSSH-Server-In-TCP' -DisplayName 'OpenSSH Server (sshd)' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22 | Out-Null }"

exit /b
