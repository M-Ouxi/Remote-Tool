@echo off
setlocal
title PC-1: Remote instellen
REM ============================================================
REM  pc1-remote.bat  -  draai dit op PC-1 (de pc waarmee je bestuurt)
REM  Bevat de geheime sleutel die bij pc2-server.bat hoort. Zet dit
REM  bestand dus niet op een plek waar anderen erbij kunnen: wie dit
REM  bestand heeft, kan bij PC-2 zonder wachtwoord.
REM  Vraagt eenmalig het IP-adres en de gebruikersnaam van PC-2.
REM  Daarna typ je alleen nog "Remote" en zit je erin.
REM  Veilig om opnieuw te draaien (bijv. als het IP-adres verandert).
REM ============================================================

set "SELF=%~f0"
set "PS1=%TEMP%\remote-pc1-setup.ps1"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:SELF); $i=$s.LastIndexOf('#PS-START',[StringComparison]::Ordinal); [IO.File]::WriteAllText($env:PS1,$s.Substring($i))"
if not exist "%PS1%" goto noextract
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%errorlevel%"
del "%PS1%" >nul 2>&1
if not "%RC%"=="0" pause
exit /b %RC%

:noextract
echo.
echo Kon het script niet uitpakken in de map %TEMP%.
echo.
pause
exit /b 1

#PS-START
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'PC-1: Remote instellen'

# Dit is de geheime helft van de sleutel. De publieke helft staat in
# pc2-server.bat en is daar al automatisch toegelaten. Hiermee logt
# PC-1 in zonder wachtwoord.
$PRIVKEY = @'
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtz
c2gtZWQyNTUxOQAAACA189Y4zlzf5a967chMNNlZyIVvMKXfLmYVVAKtKPW8lQAA
AIifrIWUn6yFlAAAAAtzc2gtZWQyNTUxOQAAACA189Y4zlzf5a967chMNNlZyIVv
MKXfLmYVVAKtKPW8lQAAAECp2/RW7oAF7HamRH3dLfgITsBq5emCCtg4KCaAGorI
nDXz1jjOXN/lr3rtyEw02VnIhW8wpd8uZhVUAq0o9byVAAAAAAECAwQF
-----END OPENSSH PRIVATE KEY-----
'@

function Test-Ping($ip) {
    try { return [bool](Test-Connection -ComputerName $ip -Count 2 -Quiet) } catch { return $false }
}

function Test-Ssh($ip, $ms) {
    $r = [pscustomobject]@{ State = 'timeout'; Banner = '' }
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $a = $c.BeginConnect($ip, 22, $null, $null)
        if (-not $a.AsyncWaitHandle.WaitOne($ms)) { return $r }
        try { $c.EndConnect($a) } catch { $r.State = 'refused'; return $r }
        $r.State = 'open'
        $s = $c.GetStream()
        $s.ReadTimeout = 3000
        $buf = New-Object byte[] 255
        $n = $s.Read($buf, 0, 255)
        if ($n -gt 0) { $r.Banner = [Text.Encoding]::ASCII.GetString($buf, 0, $n).Trim() }
    }
    catch { }
    finally { $c.Close() }
    return $r
}

Clear-Host
Write-Host '==========================================' -ForegroundColor Cyan
Write-Host '  PC-1: Remote instellen' -ForegroundColor Cyan
Write-Host '==========================================' -ForegroundColor Cyan
Write-Host ''

if (-not (Get-Command ssh.exe -ErrorAction SilentlyContinue)) {
    Write-Host 'De SSH-client is niet gevonden op deze pc.' -ForegroundColor Red
    Write-Host 'Installeer hem via Instellingen > Apps > Optionele onderdelen > OpenSSH-client.'
    exit 1
}

# ---- Sleutel op schijf zetten (eenmalig, alleen leesbaar voor jezelf) ----
$tools = Join-Path $env:USERPROFILE 'RemoteTools'
New-Item -ItemType Directory -Force -Path $tools | Out-Null
$keyPath = Join-Path $tools 'pc2.key'
# Een oude sleutel eerst weghalen: na een eerdere run is het bestand alleen-lezen.
if (Test-Path -LiteralPath $keyPath) {
    & icacls.exe $keyPath /grant:r ("$env:USERDOMAIN\$env:USERNAME`:F") | Out-Null
    Remove-Item -LiteralPath $keyPath -Force
}
# ssh wil LF-regeleinden en een regeleinde aan het eind van de sleutel. Zonder dat
# meldt ssh 'invalid format', negeert de sleutel en vraagt om een wachtwoord.
$keyText = (($PRIVKEY -replace "`r", '').Trim()) + "`n"
[IO.File]::WriteAllText($keyPath, $keyText, (New-Object System.Text.ASCIIEncoding))
& icacls.exe $keyPath /inheritance:r /grant:r ("$env:USERDOMAIN\$env:USERNAME`:R") | Out-Null

# Controleren of ssh de sleutel echt kan lezen
$PUBB64 = 'AAAAC3NzaC1lZDI1NTE5AAAAIDXz1jjOXN/lr3rtyEw02VnIhW8wpd8uZhVUAq0o9byV'
$keyOk = $false
if (Get-Command ssh-keygen.exe -ErrorAction SilentlyContinue) {
    $ErrorActionPreference = 'Continue'
    $chk = (& ssh-keygen.exe -y -f $keyPath 2>&1 | Out-String)
    $ErrorActionPreference = 'Stop'
    $keyOk = $chk.Contains($PUBB64)
}
else { $keyOk = $true }
if (-not $keyOk) {
    Write-Host 'LET OP: ssh kan het sleutelbestand niet lezen of het is de verkeerde sleutel.' -ForegroundColor Red
    Write-Host ('       Bestand: ' + $keyPath)
    Write-Host '       Zonder geldige sleutel vraagt PC-2 om een wachtwoord of weigert de verbinding.'
    Write-Host ''
}
$kh = Join-Path $tools 'known_hosts'
if (Test-Path $kh) { Remove-Item $kh -Force }

# ---- Eigen netwerk tonen ----
$mine = @(Get-NetIPConfiguration -ErrorAction SilentlyContinue |
    Where-Object { $_.IPv4DefaultGateway -and $_.IPv4Address } |
    ForEach-Object { $_.IPv4Address.IPAddress })
if ($mine.Count -gt 0) {
    Write-Host ('Het IP-adres van deze pc (PC-1): ' + ($mine -join ', '))
    Write-Host 'Het IP-adres van PC-2 moet met (bijna) dezelfde cijfers beginnen, bijvoorbeeld beide 192.168.1.x.'
    Write-Host ''
}
Write-Host 'Typ het IP-adres uit de melding die pc2-server.bat op PC-2 liet zien.'
Write-Host 'Dit vraag ik maar deze ene keer; daarna typ je alleen nog Remote.'
Write-Host ''

# ---- Adres en account van PC-2 vragen ----
do {
    $pc = (Read-Host 'IP-adres of computernaam van PC-2').Trim()
    $candidates = @()
    if (-not $pc) {
        Write-Host 'Vul een adres in.' -ForegroundColor Yellow
        continue
    }
    $parsed = $null
    if ([System.Net.IPAddress]::TryParse($pc, [ref]$parsed) -and ($parsed.AddressFamily -eq 'InterNetwork')) {
        $candidates = @($pc)
    }
    else {
        try {
            $candidates = @([System.Net.Dns]::GetHostAddresses($pc) |
                Where-Object { $_.AddressFamily -eq 'InterNetwork' } |
                ForEach-Object { $_.ToString() })
        }
        catch { }
        if ($candidates.Count -eq 0) {
            Write-Host ("De naam '" + $pc + "' kan niet worden gevonden. Gebruik het IP-adres van PC-2.") -ForegroundColor Yellow
        }
    }
    Write-Host ''
} while ($candidates.Count -eq 0)

# ---- Controleren of het adres wel naar een andere pc wijst ----
$allMine = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object { $_.IPAddress })
Write-Host ('Gevonden adres: ' + ($candidates -join ', '))
foreach ($ip in $candidates) {
    if ($allMine -contains $ip) {
        Write-Host ('LET OP: ' + $ip + ' is een adres van DEZE pc (PC-1), niet van PC-2.') -ForegroundColor Red
        Write-Host '       Gebruik het IP-adres uit de melding van pc2-server.bat (of typ ipconfig op PC-2).' -ForegroundColor Red
        $stop = Read-Host 'Toch doorgaan met dit adres? (j/n) [n]'
        if ($stop -notmatch '^[jJyY]') { exit 1 }
    }
    elseif ($ip -like '192.168.56.*') {
        Write-Host ('LET OP: ' + $ip + ' is het standaardadres van een VirtualBox-netwerk, geen gewoon thuisnetwerk-adres.') -ForegroundColor Yellow
        Write-Host '       Gebruik liever het IP-adres uit de melding van pc2-server.bat.' -ForegroundColor Yellow
    }
}
Write-Host ''

# ---- Verbinding testen ----
Write-Host 'Verbinding testen...' -ForegroundColor Cyan
$chosen = $null
$firstPing = $false
$firstState = 'timeout'
$idx = 0
foreach ($ip in $candidates) {
    Write-Host ('  ' + $ip)
    $ping = Test-Ping $ip
    $ssh = Test-Ssh $ip 5000
    if ($ping) { Write-Host '    ping:      antwoord ontvangen' -ForegroundColor Green }
    else { Write-Host '    ping:      geen antwoord' -ForegroundColor Yellow }
    if (($ssh.State -eq 'open') -and ($ssh.Banner -like 'SSH-*')) {
        Write-Host ('    poort 22:  open, SSH-server antwoordt (' + $ssh.Banner + ')') -ForegroundColor Green
        $chosen = $ip
        break
    }
    elseif ($ssh.State -eq 'open') { Write-Host '    poort 22:  open, maar er antwoordt geen SSH-server' -ForegroundColor Yellow }
    elseif ($ssh.State -eq 'refused') { Write-Host '    poort 22:  geweigerd (PC-2 is bereikbaar, maar er draait geen SSH-server)' -ForegroundColor Yellow }
    else { Write-Host '    poort 22:  geen antwoord (time-out)' -ForegroundColor Yellow }
    if ($idx -eq 0) { $firstPing = $ping; $firstState = $ssh.State }
    $idx++
}

if ($chosen) {
    $target = $chosen
    Write-Host ''
    Write-Host 'PC-2 is bereikbaar en de SSH-server werkt.' -ForegroundColor Green
}
else {
    $target = $candidates[0]
    Write-Host ''
    Write-Host 'PC-2 is NIET bereikbaar via SSH. Waarschijnlijke oorzaak:' -ForegroundColor Red
    if ($firstState -eq 'refused') {
        Write-Host '  De SSH-server draait niet. Draai pc2-server.bat op PC-2 en wacht op de melding "PC-2 is klaar".'
    }
    elseif ($firstPing) {
        Write-Host '  PC-2 is wel bereikbaar (ping werkt), maar poort 22 wordt geblokkeerd.'
        Write-Host '  Draai pc2-server.bat opnieuw op PC-2 en lees de LET OP-regels in de melding.'
        Write-Host '  Vaak is het een andere firewall of antivirus op PC-2, of "Alle binnenkomende verbindingen blokkeren".'
    }
    else {
        Write-Host '  PC-2 reageert helemaal niet. Controleer:'
        Write-Host '   - Staat PC-2 aan en niet in slaapstand? Draai anders pc2-server.bat nog een keer.'
        Write-Host '   - Klopt het IP-adres? Typ ipconfig op PC-2.'
        Write-Host '   - Zitten beide pc''s op hetzelfde netwerk (geen gastnetwerk, geen VPN aan)?'
        Write-Host '   - Heb je pc2-server.bat op PC-2 gedraaid en de melding "PC-2 is klaar" gezien?'
    }
    Write-Host ''
    $a = Read-Host 'Het Remote-commando toch aanmaken? (j/n) [j]'
    if ($a -match '^[nN]') { exit 1 }
}

do {
    $user2 = (Read-Host 'Gebruikersnaam van het Windows-account op PC-2 (zie de bovenkant van het Startmenu op PC-2)').Trim()
    if (-not $user2) { Write-Host 'Vul een gebruikersnaam in.' -ForegroundColor Yellow }
} while (-not $user2)

# ---- Remote.cmd aanmaken: IP en gebruiker liggen al vast, geen vragen meer ----
$common = @('-4', '-o', 'ConnectTimeout=8', '-o', 'StrictHostKeyChecking=accept-new', '-o', ('UserKnownHostsFile=' + $kh), '-o', 'IdentitiesOnly=yes', '-o', 'BatchMode=yes', '-o', 'PreferredAuthentications=publickey', '-i', $keyPath, '-l', $user2)

$cmdLines = New-Object System.Collections.Generic.List[string]
$cmdLines.Add('@echo off')
$cmdLines.Add('setlocal EnableExtensions')
$cmdLines.Add('set "RT=%~dp0"')
$cmdLines.Add(('set "HOST=' + $target + '"'))
$cmdLines.Add(('set "RUSER=' + $user2 + '"'))
$cmdLines.Add('set "H=%~1"')
$cmdLines.Add('if defined H set "HOST=%H%"')
$cmdLines.Add('set "REST="')
$cmdLines.Add('if defined H shift')
$cmdLines.Add(':nextarg')
$cmdLines.Add('if "%~1"=="" goto run')
$cmdLines.Add('set REST=%REST% %1')
$cmdLines.Add('shift')
$cmdLines.Add('goto nextarg')
$cmdLines.Add(':run')
$cmdLines.Add('if defined REST goto cmdmode')
$cmdLines.Add('ssh -t -4 -o ConnectTimeout=8 -o ServerAliveInterval=30 -o StrictHostKeyChecking=accept-new -o "UserKnownHostsFile=%RT%known_hosts" -o IdentitiesOnly=yes -o BatchMode=yes -o PreferredAuthentications=publickey -i "%RT%pc2.key" -l %RUSER% %HOST% "powershell -NoLogo -NoExit -ExecutionPolicy Bypass -File C:\ProgramData\RemoteSetup\shell.ps1"')
$cmdLines.Add('exit /b %errorlevel%')
$cmdLines.Add(':cmdmode')
$cmdLines.Add('ssh -4 -o ConnectTimeout=8 -o ServerAliveInterval=30 -o StrictHostKeyChecking=accept-new -o "UserKnownHostsFile=%RT%known_hosts" -o IdentitiesOnly=yes -o BatchMode=yes -o PreferredAuthentications=publickey -i "%RT%pc2.key" -l %RUSER% %HOST% %REST%')
$cmdLines.Add('exit /b %errorlevel%')
Set-Content -Path (Join-Path $tools 'Remote.cmd') -Value $cmdLines -Encoding ascii

# ---- Script op PC-2 klaarzetten: landt in de map van de ingelogde gebruiker ----
$remoteShell = @'
$ErrorActionPreference = 'SilentlyContinue'
try {
    $u = (Get-CimInstance Win32_ComputerSystem).UserName
    if ($u) {
        $sid = (New-Object System.Security.Principal.NTAccount($u)).Translate([System.Security.Principal.SecurityIdentifier]).Value
        $lp = (Get-CimInstance Win32_UserProfile -Filter ("SID='" + $sid + "'")).LocalPath
        if ($lp -and (Test-Path -LiteralPath $lp)) {
            Set-Location -LiteralPath $lp
            Write-Host ('Verbonden met PC-2. Je zit in de map van de ingelogde gebruiker: ' + $u) -ForegroundColor Green
        }
    }
    else {
        Write-Host 'Verbonden met PC-2. Er is op dit moment niemand ingelogd op PC-2.' -ForegroundColor Yellow
    }
}
catch { }
'@
$remoteCmd = "powershell -NoProfile -Command `"New-Item -ItemType Directory -Force -Path C:\ProgramData\RemoteSetup | Out-Null; Set-Content -Path C:\ProgramData\RemoteSetup\shell.ps1 -Encoding ascii -Value @'`n$remoteShell`n'@`""
# ssh meldt 'Permanently added ... known hosts' via stderr; Windows PowerShell 5.1 ziet dat
# met ErrorActionPreference=Stop als fout. Daarom hier tijdelijk op Continue.
$ErrorActionPreference = 'Continue'
try { & ssh.exe @common $target $remoteCmd 2>&1 | Out-Null } catch { }
$ErrorActionPreference = 'Stop'

# ---- Map aan gebruikers-PATH toevoegen ----
$p = [Environment]::GetEnvironmentVariable('Path', 'User')
if (-not $p) { $p = '' }
if (($p -split ';') -notcontains $tools) {
    [Environment]::SetEnvironmentVariable('Path', ($p.TrimEnd(';') + ';' + $tools).TrimStart(';'), 'User')
}

Write-Host ''
Write-Host 'Het commando "Remote" is aangemaakt.' -ForegroundColor Green

# ---- Direct testen ----
Write-Host ''
$go = Read-Host 'Nu meteen verbinden met PC-2 om te testen? (j/n) [j]'
if (-not $go) { $go = 'j' }
if ($go -match '^[jJyY]') {
    Write-Host ''
    Write-Host 'Verbinden, zonder wachtwoord... Typ "exit" om terug te gaan naar PC-1.' -ForegroundColor Cyan
    Write-Host ''
    & (Join-Path $tools 'Remote.cmd')
    $rc = $LASTEXITCODE
    Write-Host ''
    if ($rc -eq 255) {
        Write-Host 'Verbinden is niet gelukt. Lees de melding hierboven:' -ForegroundColor Yellow
        Write-Host '  - "Permission denied (publickey)": PC-2 weigert de sleutel. Controleer de gebruikersnaam'
        Write-Host '    (zie bovenkant Startmenu op PC-2),'
        Write-Host '    en draai pc2-server.bat opnieuw op PC-2 om de sleutel opnieuw toe te laten.'
        Write-Host '  - "Connection timed out": zie de tips hierboven; draai pc2-server.bat opnieuw.'
        Write-Host '  - "HOST IDENTIFICATION HAS CHANGED": draai dit bestand (pc1-remote.bat) gewoon opnieuw.'
    }
}

Write-Host ''
Write-Host '==========================================' -ForegroundColor Green
Write-Host '  Gebruik' -ForegroundColor Green
Write-Host '==========================================' -ForegroundColor Green
Write-Host '  Open een NIEUWE terminal en typ:'
Write-Host ''
Write-Host '      Remote' -ForegroundColor Cyan
Write-Host ''
Write-Host '  Je zit dan meteen in PC-2, zonder iets in te vullen, in de map van de'
Write-Host '  gebruiker die daar is ingelogd. cd, ls en dir werken allemaal.'
Write-Host '  Typ "exit" om terug te gaan naar PC-1.'
Write-Host ''
Write-Host '  Los commando zonder sessie, bijvoorbeeld:'
Write-Host '      Remote ls C:\Users' -ForegroundColor Cyan
Write-Host ''
Write-Host '  Verandert het IP-adres van PC-2? Draai dit bestand dan opnieuw.'
Write-Host ''
[void](Read-Host 'Druk op Enter om te sluiten')
exit 0